-- MySQL dump 10.17  Distrib 10.3.25-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: plb_2104
-- ------------------------------------------------------
-- Server version	10.3.25-MariaDB-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `absences`
--

DROP TABLE IF EXISTS `absences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `absences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `perso_id` int(11) NOT NULL DEFAULT 0,
  `debut` datetime NOT NULL,
  `fin` datetime NOT NULL,
  `motif` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `motif_autre` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `commentaires` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `etat` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `demande` datetime NOT NULL,
  `valide` int(11) NOT NULL DEFAULT 0,
  `validation` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `valide_n1` int(11) NOT NULL DEFAULT 0,
  `validation_n1` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pj1` int(1) DEFAULT 0,
  `pj2` int(1) DEFAULT 0,
  `so` int(1) DEFAULT 0,
  `groupe` varchar(14) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cal_name` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ical_key` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_modified` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uid` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rrule` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_origin` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `cal_name` (`cal_name`(250)),
  KEY `perso_id` (`perso_id`),
  KEY `debut` (`debut`),
  KEY `fin` (`fin`),
  KEY `groupe` (`groupe`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `absences`
--

LOCK TABLES `absences` WRITE;
/*!40000 ALTER TABLE `absences` DISABLE KEYS */;
/*!40000 ALTER TABLE `absences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `absences_documents`
--

DROP TABLE IF EXISTS `absences_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `absences_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `absence_id` int(11) NOT NULL,
  `filename` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `absences_documents`
--

LOCK TABLES `absences_documents` WRITE;
/*!40000 ALTER TABLE `absences_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `absences_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `absences_infos`
--

DROP TABLE IF EXISTS `absences_infos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `absences_infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `debut` date NOT NULL DEFAULT '0000-00-00',
  `fin` date NOT NULL DEFAULT '0000-00-00',
  `texte` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `absences_infos`
--

LOCK TABLES `absences_infos` WRITE;
/*!40000 ALTER TABLE `absences_infos` DISABLE KEYS */;
/*!40000 ALTER TABLE `absences_infos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `absences_recurrentes`
--

DROP TABLE IF EXISTS `absences_recurrentes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `absences_recurrentes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `perso_id` int(11) DEFAULT NULL,
  `event` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `end` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_update` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `last_check` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `perso_id` (`perso_id`),
  KEY `end` (`end`),
  KEY `last_check` (`last_check`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `absences_recurrentes`
--

LOCK TABLES `absences_recurrentes` WRITE;
/*!40000 ALTER TABLE `absences_recurrentes` DISABLE KEYS */;
/*!40000 ALTER TABLE `absences_recurrentes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acces`
--

DROP TABLE IF EXISTS `acces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `acces` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `groupe_id` int(11) NOT NULL,
  `groupe` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `page` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordre` int(2) NOT NULL DEFAULT 0,
  `categorie` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acces`
--

LOCK TABLES `acces` WRITE;
/*!40000 ALTER TABLE `acces` DISABLE KEYS */;
INSERT INTO `acces` VALUES (1,'Authentification',99,'','authentification.php',0,''),(2,'Planning - Index',99,'','planning/index.php',0,''),(3,'Planning par poste - Index',99,'','planning/poste/index.php',0,''),(4,'Planning par poste - Semaine',99,'','planning/poste/semaine.php',0,''),(5,'Aide',99,'','/help',0,''),(6,'Absences - Index',100,'','absences/index.php',0,''),(7,'Absences - Voir',100,'','absences/voir.php',0,''),(8,'Absences - Ajouter',100,'','/absence',0,''),(9,'Personnel - Password',100,'','personnel/password.php',0,''),(11,'Agenda - index',100,'Agenda','/calendar',0,''),(91,'Absences - Voir document',100,'','/absences/document',0,'Absences'),(13,'Absences - Modif2',100,'','absences/modif2.php',0,''),(14,'Absences - Suppression',100,'','absences/delete.php',0,''),(15,'Absences - Infos',201,'Gestion des absences, validation niveau 1','/absences/info',30,'Absences'),(16,'Personnel - Index',4,'Voir les fiches des agents','',60,'Agents'),(17,'Personnel - Modif',4,'Voir les fiches des agents','/agent',60,'Agents'),(18,'Liste des postes - Index',5,'Gestion des postes','/position',160,'Postes'),(21,'Planning Poste - Suppression',301,'Création / modification des plannings, utilisation et gestion des modèles','planning/poste/supprimer.php',110,'Planning'),(22,'Planning Poste - Importer un modèle',301,'Création / modification des plannings, utilisation et gestion des modèles','planning/poste/importer.php',110,'Planning'),(23,'Planning Poste - Enregistrer un modèle',301,'Création / modification des plannings, utilisation et gestion des modèles','planning/poste/enregistrer.php',110,'Planning'),(24,'Statistiques',17,'Accès aux statistiques','',170,'Statistiques'),(26,'stats postes par agent',17,'Accès aux statistiques','statistiques/postes.php',170,'Statistiques'),(32,'Liste des agents présents et absents',1301,'Accès aux statistiques Présents / Absents','/statistics/attendeesmissing',171,'Statistiques'),(33,'Configuration avancée',20,'Configuration avancée','/config',0,''),(34,'Personnel - Suppression',21,'Gestion des agents','personnel/suppression.php',70,'Agents'),(35,'Personnel - Valid',21,'Gestion des agents','',70,'Agents'),(36,'Gestion du personnel',21,'Gestion des agents','',70,'Agents'),(38,'Configuration des horaires des tableaux',22,'Configuration des tableaux','planning/postes_cfg/horaires.php',140,'Planning'),(39,'Configuration des horaires des tableaux',22,'Configuration des tableaux','',140,'Planning'),(40,'Configuration des lignes des tableaux',22,'Configuration des tableaux','planning/postes_cfg/lignes.php',140,'Planning'),(41,'Activités - Index',5,'Gestion des postes','/skill',160,'Postes'),(42,'Activités - Modification',5,'Gestion des postes','/skill/add',160,'Postes'),(43,'Activités - Validation',5,'Gestion des postes','activites/valid.php',160,'Postes'),(48,'Configuration des tableaux - Modif',22,'Configuration des tableaux','',140,'Planning'),(49,'Informations',23,'Informations','/admin/info',0,''),(52,'Informations',23,'Informations','/admin/info/add',0,''),(53,'Configuration des tableaux - Modif',22,'Configuration des tableaux','',140,'Planning'),(54,'Configuration des tableaux - Modif',22,'Configuration des tableaux','',140,'Planning'),(55,'Configuration des tableaux - Modif',22,'Configuration des tableaux','',140,'Planning'),(56,'Modification des plannings - menudiv',1001,'Modification des plannings','planning/poste/menudiv.php',120,'Planning'),(57,'Modification des plannings - majdb',1001,'Modification des plannings','planning/poste/majdb.php',120,'Planning'),(58,'Personnel - Importation',21,'Gestion des agents','personnel/import.php',70,'Agents'),(59,'Jours fériés',25,'Gestion des jours fériés','/closingday',0,''),(61,'Voir les agendas de tous',3,'Voir les agendas de tous','',55,'Agendas'),(62,'Modifier ses propres absences',6,'Modifier ses propres absences','',20,'Absences'),(64,'Gestion des absences, validation niveau 2',501,'Gestion des absences, validation niveau 2','',40,'Absences'),(66,'Gestion des absences, pièces justificatives',701,'Gestion des absences, pièces justificatives','',50,'Absences'),(67,'Planning Hebdo - Admin N1',1101,'Gestion des heures de présences, validation niveau 1','',80,'Heures de présence'),(73,'Planning Hebdo - Admin N2',1201,'Gestion des heures de présences, validation niveau 2','',90,'Heures de présence'),(74,'Modification des commentaires des plannings',801,'Modification des commentaires des plannings','',130,'Planning'),(75,'Griser les cellules des plannings',901,'Griser les cellules des plannings','',125,'Planning'),(77,'Agents volants',301,'Création / modification des plannings, utilisation et gestion des modèles','planning/volants/index.php',110,'Planning'),(78,'Congés - Index',100,'','conges/index.php',0,''),(79,'Congés - Liste',100,'','/holiday/index',0,''),(80,'Congés - Nouveau',100,'','/holiday/new',0,''),(81,'Congés - Modifier',100,'','/holiday/edit',0,''),(82,'Gestion des congés, validation niveau 2',601,'Gestion des congés, validation niveau 2','',76,'Congés'),(83,'Congés - Infos',100,'','conges/infos.php',0,''),(85,'Congés - Récupération',100,'','conges/recuperation_modif.php',0,''),(86,'Gestion des congés, validation niveau 1',401,'Gestion des congés, validation niveau 1','',75,'Congés'),(87,'Congés - Compte Épargne Temps',100,'','conges/cet.php',0,''),(88,'Congés - Crédits',100,'','conges/credits.php',0,''),(89,'Congés - Récupérations',100,'','conges/recuperation_valide.php',0,''),(90,'Congés - Poser des récupérations',100,'','conges/recup_pose.php',0,''),(92,'Absences - liste documents',100,'','/absences/documents',0,'Absences'),(93,'Enregistrement d\'absences pour plusieurs agents',9,'Enregistrement d\'absences pour plusieurs agents','',25,'Absences'),(94,'Congés - Enregistrer',100,'','/holiday',0,''),(95,'Congés - Enregistrer',100,'','/holiday',0,'');
/*!40000 ALTER TABLE `acces` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activites`
--

DROP TABLE IF EXISTS `activites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `supprime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activites`
--

LOCK TABLES `activites` WRITE;
/*!40000 ALTER TABLE `activites` DISABLE KEYS */;
INSERT INTO `activites` VALUES (1,'Assistance audiovisuel',NULL),(2,'Assistance autoformation',NULL),(3,'Communication',NULL),(4,'Communication réserve',NULL),(5,'Inscription',NULL),(6,'Prêt/retour de document',NULL),(7,'Prêt de matériel',NULL),(8,'Rangement',NULL),(9,'Renseignement',NULL),(10,'Renseignement bibliographique',NULL),(11,'Renseignement réserve',NULL),(12,'Renseignement spécialisé',NULL);
/*!40000 ALTER TABLE `activites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appel_dispo`
--

DROP TABLE IF EXISTS `appel_dispo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appel_dispo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site` int(11) NOT NULL DEFAULT 1,
  `poste` int(11) NOT NULL DEFAULT 0,
  `date` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debut` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fin` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `destinataires` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sujet` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appel_dispo`
--

LOCK TABLES `appel_dispo` WRITE;
/*!40000 ALTER TABLE `appel_dispo` DISABLE KEYS */;
/*!40000 ALTER TABLE `appel_dispo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valeur` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `commentaires` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `categorie` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valeurs` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordre` int(2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nom` (`nom`)
) ENGINE=MyISAM AUTO_INCREMENT=173 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES (1,'Version','info','21.04.00.000','Version de l&apos;application',' Divers','',0),(2,'URL','info','http://bionic','URL de l&apos;application',' Divers','',10),(3,'Mail-IsEnabled','boolean','0','Active ou d&eacute;sactive l&apos;envoi des mails','Messagerie','',10),(4,'toutlemonde','boolean','0','Affiche ou non l&apos;utilisateur \"tout le monde\" dans le menu.','Planning','',5),(5,'Mail-IsMail-IsSMTP','enum','IsSMTP','Classe &agrave; utiliser : SMTP, fonction PHP IsMail','Messagerie','IsSMTP,IsMail',10),(6,'Mail-WordWrap','','50','','Messagerie','',10),(7,'Mail-Hostname','','','Nom d\'h&ocirc;te du serveur pour l&apos;envoi des mails.','Messagerie','',10),(8,'Mail-Host','','','Nom FQDN ou IP du serveur SMTP.','Messagerie','',10),(9,'Mail-Port','','25','Port du serveur SMTP','Messagerie','',10),(10,'Mail-SMTPSecure','enum','','Cryptage utilis&eacute; par le serveur STMP.','Messagerie',',ssl,tls',10),(11,'Mail-SMTPAuth','boolean','0','Le serveur SMTP requiert-il une authentification?','Messagerie','',10),(12,'Mail-Username','','','Nom d&apos;utilisateur pour le serveur SMTP.','Messagerie','',10),(13,'Mail-Password','password','::9281467817f8b1d4fb2bd7b8378eb7f3','Mot de passe pour le serveur SMTP','Messagerie','',10),(14,'Mail-From','','notifications-planningbiblio@biblibre.com','Adresse email de l&apos;expediteur.','Messagerie','',10),(15,'Mail-FromName','','Planning','Nom de l&apos;expediteur.','Messagerie','',10),(16,'Mail-Signature','textarea','Ce message a été envoyé par Planning Biblio.\r\nMerci de ne pas y répondre.','Signature des e-mails','Messagerie','',10),(17,'Dimanche','boolean','0','Utiliser le planning le dimanche',' Divers','',20),(18,'nb_semaine','enum','1','Nombre de semaines pour la rotation des heures de présence','Heures de présence','1,2,3',0),(19,'dateDebutPlHebdo','date','','Date de début permettant la rotation des heures de présence (pour l\'utilisation de 3 plannings hebdomadaires. Format JJ/MM/AAAA)','Heures de présence','',0),(20,'ctrlHresAgents','boolean','1','Contr&ocirc;le des heures des agents le samedi et le dimanche','Planning','',0),(21,'agentsIndispo','boolean','1','Afficher les agents indisponibles','Planning','',5),(22,'Granularite','enum2','30','Granularit&eacute; des champs horaires.',' Divers','[[60,\"Heure\"],[30,\"Demi-heure\"],[15,\"Quart d&apos;heure\"],[5,\"5 minutes\"]]',30),(23,'Absences-planning','enum2','0','Afficher la liste des absences sur la page du planning','Absences','[[0,\"\"],[1,\"simple\"],[2,\"d&eacute;taill&eacute;\"],[3,\"absents et pr&eacute;sents\"]]',25),(24,'Auth-Mode','enum','SQL','M&eacute;thode d&apos;authentification','Authentification','SQL,LDAP,LDAP-SQL,CAS,CAS-SQL',7),(25,'Absences-apresValidation','boolean','1','Autoriser l\'enregistrement d\'absences après validation des plannings','Absences','',10),(26,'Absences-planningVide','boolean','1','Autoriser l\'enregistrement d\'absences sur des plannings en cours d\'élaboration','Absences','',8),(27,'Multisites-nombre','enum','1','Nombre de sites','Multisites','1,2,3,4,5,6,7,8,9,10',10),(28,'Multisites-site1','text','','Nom du site N°1','Multisites','',20),(29,'Multisites-site1-mail','text','','Adresses e-mails de la cellule planning du site N°1, séparées par des ;','Multisites','',25),(30,'Multisites-site2','text','','Nom du site N°2','Multisites','',30),(31,'Multisites-site2-mail','text','','Adresses e-mails de la cellule planning du site N°2, séparées par des ;','Multisites','',35),(32,'Multisites-site3','text','','Nom du site N°3','Multisites','',40),(33,'Multisites-site3-mail','text','','Adresses e-mails de la cellule planning du site N°3, séparées par des ;','Multisites','',45),(34,'Multisites-site4','text','','Nom du site N°4','Multisites','',50),(35,'Multisites-site4-mail','text','','Adresses e-mails de la cellule planning du site N°4, séparées par des ;','Multisites','',55),(36,'Multisites-site5','text','','Nom du site N°5','Multisites','',60),(37,'Multisites-site5-mail','text','','Adresses e-mails de la cellule planning du site N°5, séparées par des ;','Multisites','',65),(38,'Multisites-site6','text','','Nom du site N°6','Multisites','',70),(39,'Multisites-site6-mail','text','','Adresses e-mails de la cellule planning du site N°6, séparées par des ;','Multisites','',75),(40,'Multisites-site7','text','','Nom du site N°7','Multisites','',80),(41,'Multisites-site7-mail','text','','Adresses e-mails de la cellule planning du site N°7, séparées par des ;','Multisites','',85),(42,'Multisites-site8','text','','Nom du site N°8','Multisites','',90),(43,'Multisites-site8-mail','text','','Adresses e-mails de la cellule planning du site N°8, séparées par des ;','Multisites','',95),(44,'Multisites-site9','text','','Nom du site N°9','Multisites','',100),(45,'Multisites-site9-mail','text','','Adresses e-mails de la cellule planning du site N°9, séparées par des ;','Multisites','',105),(46,'Multisites-site10','text','','Nom du site N°10','Multisites','',110),(47,'Multisites-site10-mail','text','','Adresses e-mails de la cellule planning du site N°10, séparées par des ;','Multisites','',115),(48,'hres4semaines','boolean','0','Afficher le total d\'heures des 4 dernières semaine dans le menu','Planning','',5),(49,'Auth-Anonyme','boolean','0','Autoriser les logins anonymes','Authentification','',7),(50,'EDTSamedi','enum2','0','Horaires différents les semaines avec samedi travaillé et semaines à ouverture restreinte','Heures de présence','[[0, \"Désactivé\"], [1, \"Horaires différents les semaines avec samedi travaillé\"], [2, \"Horaires différents les semaines avec samedi travaillé et les semaines à ouverture restreinte\"]]',0),(164,'Absences-journeeEntiere','boolean','1','Le paramètre \"Journée(s) entière(s)\" est coché par défaut lors de la saisie d\'une absence.','Absences','',38),(51,'ClasseParService','boolean','0','Classer les agents par service dans le menu d&eacute;roulant du planning','Planning','',5),(52,'Alerte2SP','boolean','1','Alerter si l&apos;agent fera 2 plages de service public de suite','Planning','',5),(53,'CatAFinDeService','boolean','0','Alerter si aucun agent de cat&eacute;gorie A n&apos;est plac&eacute; en fin de service','Planning','',0),(54,'Conges-Recuperations','enum2','1','Traiter les r&eacute;cup&eacute;rations comme les cong&eacute;s (Assembler), ou les traiter s&eacute;par&eacute;ment (Dissocier)','Congés','[[0,\"Assembler\"],[1,\"Dissocier\"]]',3),(55,'Recup-Agent','enum2','0','Type de champ pour la r&eacute;cup&eacute;ration des samedis dans la fiche des agents.<br/>Rien [vide], champ <b>texte</b> ou <b>menu d&eacute;roulant</b>','Congés','[[0,\"\"],[1,\"Texte\"],[2,\"Menu déroulant\"]]',40),(56,'Recup-SamediSeulement','boolean','0','Autoriser les demandes de récupération des samedis seulement','Congés','',20),(57,'Recup-Uneparjour','boolean','1','Autoriser une seule demande de r&eacute;cup&eacute;ration par jour','Congés','',15),(58,'Recup-DeuxSamedis','boolean','0','Autoriser les demandes de récupération pour 2 samedis','Congés','',30),(59,'Recup-DelaiDefaut','text','7','Delai pour les demandes de récupération par d&eacute;faut (en jours)','Congés','',40),(60,'Recup-DelaiTitulaire1','enum2','0','Delai pour les demandes de récupération des titulaires pour 1 samedi (en mois)','Congés','[[-1,\"Défaut\"],[0,0],[1,1],[2,2],[3,3],[4,4],[5,5]]',50),(61,'Recup-DelaiTitulaire2','enum2','0','Delai pour les demandes de récupération des titulaires pour 2 samedis (en mois)','Congés','[[-1,\"Défaut\"],[0,0],[1,1],[2,2],[3,3],[4,4],[5,5]]',60),(62,'Recup-DelaiContractuel1','enum2','0','Delai pour les demandes de récupération des contractuels pour 1 samedi (en semaines)','Congés','[[-1,\"Défaut\"],[0,0],[1,1],[2,2],[3,3],[4,4],[5,5]]',70),(63,'Recup-DelaiContractuel2','enum2','0','Delai pour les demandes de récupération des contractuels pour 2 samedis (en semaines)','Congés','[[-1,\"Défaut\"],[0,0],[1,1],[2,2],[3,3],[4,4],[5,5]]',80),(64,'Recup-notifications1','checkboxes','[\"2\"]','Destinataires des notifications de nouvelles demandes de crédit de récupérations','Congés','[[0,\"Agents ayant le droit de gérer les récupérations\"],[1,\"Responsables directs\"],[2,\"Cellule planning\"],[3,\"Agent concerné\"]]',100),(65,'Recup-notifications2','checkboxes','[\"2\"]','Destinataires des notifications de modification de crédit de récupérations','Congés','[[0,\"Agents ayant le droit de gérer les récupérations\"],[1,\"Responsables directs\"],[2,\"Cellule planning\"],[3,\"Agent concerné\"]]',100),(66,'Recup-notifications3','checkboxes','[\"1\"]','Destinataires des notifications des validations de crédit de récupérations niveau 1','Congés','[[0,\"Agents ayant le droit de gérer les récupérations\"],[1,\"Responsables directs\"],[2,\"Cellule planning\"],[3,\"Agent concerné\"]]',100),(67,'Recup-notifications4','checkboxes','[\"3\"]','Destinataires des notifications des validations de crédit de récupérations niveau 2','Congés','[[0,\"Agents ayant le droit de gérer les récupérations\"],[1,\"Responsables directs\"],[2,\"Cellule planning\"],[3,\"Agent concerné\"]]',100),(68,'Conges-Rappels','boolean','0','Activer / D&eacute;sactiver l&apos;envoi de rappels s&apos;il y a des cong&eacute;s non-valid&eacute;s','Congés','',6),(69,'Conges-Rappels-Jours','text','14','Nombre de jours &agrave; contr&ocirc;ler pour l&apos;envoi de rappels sur les cong&eacute;s non-valid&eacute;s','Congés','',7),(70,'Conges-Rappels-N1','checkboxes','[\"Mail-Planning\"]','A qui envoyer les rappels sur les cong&eacute;s non-valid&eacute;s au niveau 1','Congés','[[\"Mail-Planning\",\"La cellule planning\"],[\"mails_responsables\",\"Les responsables hi&eacute;rarchiques\"]]',12),(71,'Conges-Rappels-N2','checkboxes','[\"mails_responsables\"]','A qui envoyer les rappels sur les cong&eacute;s non-valid&eacute;s au niveau 2','Congés','[[\"Mail-Planning\",\"La cellule planning\"],[\"mails_responsables\",\"Les responsables hi&eacute;rarchiques\"]]',14),(72,'Conges-Validation-N2','enum2','0','La validation niveau 2 des cong&eacute;s peut se faire directement ou doit attendre la validation niveau 1','Congés','[[0,\"Validation directe autoris&eacute;e\"],[1,\"Le cong&eacute; doit &ecirc;tre valid&eacute; au niveau 1\"]]',4),(73,'Conges-Enable','boolean','0','Activer le module Congés','Congés','',1),(74,'Absences-validation','boolean','0','Les absences doivent &ecirc;tre valid&eacute;es par un administrateur avant d&apos;&ecirc;tre prises en compte','Absences','',30),(75,'Absences-non-validees','boolean','1','Dans les plannings, afficher en rouge les agents pour lesquels une absence non-valid&eacute;e est enregistr&eacute;e','Absences','',35),(76,'Absences-agent-preselection','boolean','1','Présélectionner l&apos;agent connecté lors de l&apos;ajout d&apos;une nouvelle absence.','Absences','',36),(77,'Absences-tous','boolean','0','Autoriser l&apos;enregistrement d&apos;absences pour tous les agents en une fois','Absences','',37),(78,'Absences-adminSeulement','boolean','0','Autoriser la saisie des absences aux administrateurs seulement.','Absences','',20),(79,'Mail-Planning','textarea','','Adresses e-mails de la cellule planning, s&eacute;par&eacute;es par des ;','Messagerie','',10),(80,'Planning-sansRepas','boolean','1','Afficher une notification pour les Sans Repas dans le menu d&eacute;roulant et dans le planning','Planning','',10),(81,'Planning-dejaPlace','boolean','1','Afficher une notification pour les agents d&eacute;j&agrave; plac&eacute; sur un poste dans le menu d&eacute;roulant du planning','Planning','',20),(82,'Planning-Heures','boolean','1','Afficher les heures &agrave; c&ocirc;t&eacute; du nom des agents dans le menu du planning','Planning','',25),(83,'Planning-CommentairesToujoursActifs','boolean','0','Afficher la zone de commentaire m&ecirc;me si le planning n\'est pas encore commenc&eacute;.','Planning','',100),(84,'Absences-notifications-A1','checkboxes','[\"2\"]','Destinataires des notifications de nouvelles absences (Circuit A)','Absences','[[0,\"Agents ayant le droit de g&eacute;rer les absences\"],[1,\"Responsables directs\"],[2,\"Cellule planning\"],[3,\"Agent concern&eacute;\"]]',40),(85,'Absences-notifications-A2','checkboxes','[\"2\"]','Destinataires des notifications de modification d&apos;absences (Circuit A)','Absences','[[0,\"Agents ayant le droit de g&eacute;rer les absences\"],[1,\"Responsables directs\"],[2,\"Cellule planning\"],[3,\"Agent concern&eacute;\"]]',50),(86,'Absences-notifications-A3','checkboxes','[\"1\"]','Destinataires des notifications des validations niveau 1 (Circuit A)','Absences','[[0,\"Agents ayant le droit de g&eacute;rer les absences\"],[1,\"Responsables directs\"],[2,\"Cellule planning\"],[3,\"Agent concern&eacute;\"]]',60),(87,'Absences-notifications-A4','checkboxes','[\"3\"]','Destinataires des notifications des validations niveau 2 (Circuit A)','Absences','[[0,\"Agents ayant le droit de g&eacute;rer les absences\"],[1,\"Responsables directs\"],[2,\"Cellule planning\"],[3,\"Agent concern&eacute;\"]]',70),(88,'Absences-notifications-agent-par-agent','boolean','0','Gestion des notifications et des droits de validations agent par agent. Si cette option est activée, les paramètres Absences-notifications-A1, A2, A3 et A4 ou B1, B2, B3 et B4 seront écrasés par les choix fait dans la page de configuration des notifications du menu Administration - Notifications / Validations','Absences','',120),(89,'Absences-notifications-titre','text','','Titre personnalis&eacute; pour les notifications de nouvelles absences','Absences','',130),(90,'Absences-notifications-message','textarea','','Message personnalis&eacute; pour les notifications de nouvelles absences','Absences','',140),(91,'Statistiques-Heures','textarea','','Afficher des statistiques sur les cr&eacute;neaux horaires voulus. Les cr&eacute;neaux doivent &ecirc;tre au format 00h00-00h00 et s&eacute;par&eacute;s par des ; Exemple : 19h00-20h00; 20h00-21h00; 21h00-22h00','Statistiques','',10),(92,'Affichage-theme','text','light_blue','Th&egrave;me de l&apos;application.','Affichage','',10),(93,'Affichage-titre','text','','Titre affich&eacute; sur la page d&apos;accueil','Affichage','',20),(94,'Affichage-etages','boolean','0','Afficher les &eacute;tages des postes dans le planning','Affichage','',30),(95,'Planning-NbAgentsCellule','enum','4','Nombre d&apos;agents maximum par cellule','Planning','1,2,3,4,5,6,7,8,10,11,12,13,14,15,16,17,18,19,20',2),(96,'Planning-lignesVides','boolean','1','Afficher ou non les lignes vides dans les plannings valid&eacute;s','Planning','',3),(97,'Planning-SR-debut','enum2','12:00:00','Heure de d&eacute;but pour la v&eacute;rification des sans repas','Planning','[[\"11:00:00\",\"11h00\"],[\"11:15:00\",\"11h15\"],[\"11:30:00\",\"11h30\"],[\"11:45:00\",\"11h45\"],[\"12:00:00\",\"12h00\"],[\"12:15:00\",\"12h15\"],[\"12:30:00\",\"12h30\"],[\"12:45:00\",\"12h45\"],[\"13:00:00\",\"13h00\"],[\"13:15:00\",\"13h15\"],[\"13:30:00\",\"13h30\"],[\"13:45:00\",\"13h45\"],[\"14:00:00\",\"14h00\"],[\"14:15:00\",\"14h15\"],[\"14:30:00\",\"14h30\"],[\"14:45:00\",\"14h45\"]]',11),(98,'Planning-SR-fin','enum2','14:00:00','Heure de fin pour la v&eacute;rification des sans repas','Planning','[[\"11:15:00\",\"11h15\"],[\"11:30:00\",\"11h30\"],[\"11:45:00\",\"11h45\"],[\"12:00:00\",\"12h00\"],[\"12:15:00\",\"12h15\"],[\"12:30:00\",\"12h30\"],[\"12:45:00\",\"12h45\"],[\"13:00:00\",\"13h00\"],[\"13:15:00\",\"13h15\"],[\"13:30:00\",\"13h30\"],[\"13:45:00\",\"13h45\"],[\"14:00:00\",\"14h00\"],[\"14:15:00\",\"14h15\"],[\"14:30:00\",\"14h30\"],[\"14:45:00\",\"14h45\"],[\"15:00:00\",\"15h00\"]]',12),(99,'Planning-Absences-Heures-Hebdo','boolean','0','Prendre en compte les absences pour calculer le nombre d&apos;heures de SP &agrave; effectuer. (Module PlanningHebdo requis)','Planning','',30),(100,'CAS-Debug','boolean','0','Activer le débogage pour CAS. Créé un fichier \"cas_debug.txt\" dans le dossier \"[TEMP]\"','CAS','',50),(101,'PlanningHebdo','boolean','1','Utiliser le module “Planning Hebdo”. Ce module permet d\'enregistrer plusieurs horaires de présence par agent en définissant des périodes d\'utilisation. (Incompatible avec l\'option EDTSamedi)','Heures de présence','',40),(102,'PlanningHebdo-Agents','boolean','0','Autoriser les agents à saisir leurs heures de présence (avec le module Planning Hebdo). Les heures saisies devront être validées par un administrateur','Heures de présence','',50),(103,'PlanningHebdo-Pause2','boolean','0','2 pauses dans une journ&eacute;e','Heures de présence','',60),(104,'PlanningHebdo-notifications1','checkboxes','[\"3\"]','Destinataires des notifications d\'enregistrement de nouvelles heures de présence','Heures de présence','[[0,\"Agents ayant le droit de valider les heures de pr&eacute;sence au niveau 1\"],[1,\"Agents ayant le droit de valider les heures de pr&eacute;sence au niveau 2\"],[2,\"Responsables directs\"],[3,\"Cellule planning\"],[4,\"Agent concern&eacute;\"]]',70),(105,'PlanningHebdo-notifications2','checkboxes','[\"3\"]','Destinataires des notifications de modification des heures de présence','Heures de présence','[[0,\"Agents ayant le droit de valider les heures de pr&eacute;sence au niveau 1\"],[1,\"Agents ayant le droit de valider les heures de pr&eacute;sence au niveau 2\"],[2,\"Responsables directs\"],[3,\"Cellule planning\"],[4,\"Agent concern&eacute;\"]]',72),(106,'PlanningHebdo-notifications3','checkboxes','[\"2\"]','Destinataires des notifications des validations niveau 1','Heures de présence','[[0,\"Agents ayant le droit de valider les heures de pr&eacute;sence au niveau 1\"],[1,\"Agents ayant le droit de valider les heures de pr&eacute;sence au niveau 2\"],[2,\"Responsables directs\"],[3,\"Cellule planning\"],[4,\"Agent concern&eacute;\"]]',74),(107,'PlanningHebdo-notifications4','checkboxes','[\"4\"]','Destinataires des notifications des validations niveau 2','Heures de présence','[[0,\"Agents ayant le droit de valider les heures de pr&eacute;sence au niveau 1\"],[1,\"Agents ayant le droit de valider les heures de pr&eacute;sence au niveau 2\"],[2,\"Responsables directs\"],[3,\"Cellule planning\"],[4,\"Agent concern&eacute;\"]]',76),(108,'PlanningHebdo-notifications-agent-par-agent','boolean','0','Gestion des notifications et des droits de validations agent par agent. Si cette option est activée, les paramètres PlanningHebdo-notifications1, 2, 3 et 4 seront écrasés par les choix fait dans la page de configuration des notifications du menu Administration - Notifications / Validations','Heures de présence','',80),(109,'PlanningHebdo-Validation-N2','enum2','0','La validation niveau 2 des heures de présence peut se faire directement ou doit attendre la validation niveau 1','Heures de présence','[[0,\"Validation directe autoris&eacute;e\"],[1,\"Le planning doit &ecirc;tre valid&eacute; au niveau 1\"]]',85),(110,'Planning-Notifications','boolean','0','Envoyer une notification aux agents lors de la validation des plannings les concernant','Planning','',40),(111,'Planning-TableauxMasques','boolean','1','Autoriser le masquage de certains tableaux du planning','Planning','',50),(112,'Planning-AppelDispo','boolean','0','Permettre l&apos;envoi d&apos;un mail aux agents disponibles pour leur demander s&apos;ils sont volontaires pour occuper le poste choisi.','Planning','',60),(113,'Planning-AppelDispoSujet','text','Appel à disponibilité [poste] [date] [debut]-[fin]','Sujet du mail pour les appels &agrave; disponibilit&eacute;','Planning','',70),(114,'Planning-AppelDispoMessage','textarea','Chers tous,\r\n\r\nLe poste [poste] est vacant le [date] de [debut] à [fin].\r\n\r\nSi vous souhaitez occuper ce poste, vous pouvez répondre à cet e-mail.\r\n\r\nCordialement,\r\nLa cellule planning','Corps du mail pour les appels &agrave; disponibilit&eacute;','Planning','',80),(115,'LDAP-Host','','','Nom d&apos;h&ocirc;te ou adresse IP du serveur LDAP','LDAP','',10),(116,'LDAP-Port','','','Port du serveur LDAP','LDAP','',20),(117,'LDAP-Protocol','enum','ldap','Protocol utilis&eacute;','LDAP','ldap,ldaps',30),(118,'LDAP-Suffix','','','Base LDAP','LDAP','',40),(119,'LDAP-Filter','','','Filtre LDAP. OpenLDAP essayez \"(objectclass=inetorgperson)\" , Active Directory essayez \"(&(objectCategory=person)(objectClass=user))\". Vous pouvez bien-s&ucirc;r personnaliser votre filtre.','LDAP','',50),(120,'LDAP-RDN','','','DN de connexion au serveur LDAP, laissez vide si connexion anonyme','LDAP','',60),(121,'LDAP-Password','password','::529fa8bdd556af1e14eaee3f8b08caf6','Mot de passe de connexion','LDAP','',70),(122,'LDAP-ID-Attribute','enum','uid','Attribut d&apos;authentification (OpenLDAP : uid, Active Directory : samaccountname)','LDAP','uid,samaccountname,supannaliaslogin',80),(123,'LDAP-Matricule','text','','Attribut &agrave; importer dans le champ matricule (optionnel)','LDAP','',90),(124,'CAS-Hostname','','','Nom d&apos;h&ocirc;te du serveur CAS','CAS','',30),(125,'CAS-Port','','8080','Port serveur CAS','CAS','',30),(126,'CAS-Version','enum','2.0','Version du serveur CAS','CAS','2.0,3.0,4.0',30),(127,'CAS-CACert','','','Chemin absolut du certificat de l&apos;Autorit&eacute; de Certification. Si pas renseign&eacute;, l&apos;identit&eacute; du serveur ne sera pas v&eacute;rifi&eacute;e.','CAS','',30),(128,'CAS-SSLVersion','enum2','1','Version SSL/TLS &agrave; utiliser pour les &eacute;changes avec le serveur CAS','CAS','[[1,\"TLSv1\"],[4,\"TLSv1_0\"],[5,\"TLSv1_1\"],[6,\"TLSv1_2\"]]',45),(129,'CAS-ServiceURL','text','','URL de Planning Biblio. A renseigner seulement si la redirection ne fonctionne pas après authentification sur le serveur CAS, si vous utilisez un Reverse Proxy par exemple.','CAS','',47),(130,'CAS-URI','','cas','Page de connexion CAS','CAS','',30),(131,'CAS-URI-Logout','','cas/logout','Page de d&eacute;connexion CAS','CAS','',30),(132,'Rappels-Actifs','boolean','0','Activer les rappels','Rappels','',10),(133,'Rappels-Jours','enum2','3','Nombre de jours &agrave; contr&ocirc;ler pour les rappels','Rappels','[[1,1],[2,2],[3,3],[4,4],[5,5],[6,6],[7,7]]',20),(134,'Rappels-Renfort','boolean','0','Contr&ocirc;ler les postes de renfort lors des rappels','Rappels','',30),(135,'IPBlocker-TimeChecked','text','10','Recherche les &eacute;checs d&apos;authentification lors des N derni&egrave;res minutes. ( 0 = IPBlocker d&eacute;sactiv&eacute; )','Authentification','',40),(136,'IPBlocker-Attempts','text','5','Nombre d&apos;&eacute;checs d&apos;authentification autoris&eacute;s lors des N derni&egrave;res minutes','Authentification','',50),(137,'IPBlocker-Wait','text','10','Temps de blocage de l&apos;IP en minutes','Authentification','',60),(138,'ICS-Server1','text','','URL du 1<sup>er</sup> serveur ICS avec la variable OpenURL entre crochets. Ex: http://server.domain.com/calendars/[email].ics','ICS','',10),(139,'ICS-Pattern1','text','','Motif d&apos;absence pour les &eacute;v&eacute;nements import&eacute;s du 1<sup>er</sup> serveur. Ex: Agenda Personnel','ICS','',20),(140,'ICS-Status1','enum2','CONFIRMED','Importer tous les &eacute;v&eacute;nements ou seulement les &eacute;v&eacute;nements confirm&eacute;s (attribut STATUS = CONFIRMED). Si \"tous\" est choisi, les &eacute;v&eacute;nements non-confirm&eacute;s seront enregistr&eacute;s comme des absences en attente de validation','ICS','[[\"CONFIRMED\",\"Confirm&eacute;s\"],[\"ALL\",\"Tous\"]]',22),(141,'ICS-Server2','text','','URL du 2<sup>&egrave;me</sup> serveur ICS avec la variable OpenURL entre crochets. Ex: http://server2.domain.com/holiday/[login].ics','ICS','',30),(142,'ICS-Pattern2','text','','Motif d&apos;absence pour les &eacute;v&eacute;nements import&eacute;s du 2<sup>&egrave;me</sup> serveur. Ex: Congés','ICS','',40),(143,'ICS-Status2','enum2','CONFIRMED','Importer tous les &eacute;v&eacute;nements ou seulement les &eacute;v&eacute;nements confirm&eacute;s (attribut STATUS = CONFIRMED). Si \"tous\" est choisi, les &eacute;v&eacute;nements non-confirm&eacute;s seront enregistr&eacute;s comme des absences en attente de validation','ICS','[[\"CONFIRMED\",\"Confirm&eacute;s\"],[\"ALL\",\"Tous\"]]',42),(144,'ICS-Server3','boolean','0','Utiliser une URL d&eacute;finie pour chaque agent dans le menu Administration / Les agents','ICS','',44),(145,'ICS-Pattern3','text','','Motif d&apos;absence pour les &eacute;v&eacute;nements import&eacute;s depuis l&apos;URL d&eacute;finie dans la fiche des agents. Ex: Agenda personnel','ICS','',45),(146,'ICS-Status3','enum2','CONFIRMED','Importer tous les &eacute;v&eacute;nements ou seulement les &eacute;v&eacute;nements confirm&eacute;s (attribut STATUS = CONFIRMED). Si \"tous\" est choisi, les &eacute;v&eacute;nements non-confirm&eacute;s seront enregistr&eacute;s comme des absences en attente de validation','ICS','[[\"CONFIRMED\",\"Confirm&eacute;s\"],[\"ALL\",\"Tous\"]]',47),(147,'ICS-Export','boolean','0','Autoriser l&apos;exportation des plages de service public sous forme de calendriers ICS. Un calendrier par agent, accessible &agrave; l&apos;adresse [SERVER]/ics/calendar.php?login=[login_de_l_agent]','ICS','',60),(148,'ICS-Code','boolean','1','Prot&eacute;ger les calendriers ICS par des codes de façon &agrave; ce qu&apos;on ne puisse pas deviner les URLs. Si l&apos;option est activ&eacute;e, les URL seront du type : [SERVER]/ics/calendar.php?login=[login_de_l_agent]&amp;code=[code_al&eacute;atoire]','ICS','',70),(149,'PlanningHebdo-CSV','text','','Emplacement du fichier CSV &agrave; importer (importation automatis&eacute;e) Ex: /dossier/fichier.csv','Heures de présence','',90),(150,'Agenda-Plannings-Non-Valides','boolean','0','Afficher ou non les plages de service public des plannings non valid&eacute;s dans les agendas.','Agenda','',10),(151,'Planning-agents-volants','boolean','0','Utiliser le module \"Agents volants\" permettant de diff&eacute;rencier un groupe d&apos;agents dans le planning','Planning','',90),(152,'Hamac-csv','text','','Chemin d&apos;acc&egrave;s au fichier CSV pour l&apos;importation des absences depuis Hamac','Hamac','',10),(153,'Hamac-motif','text','','Motif pour les absences import&eacute;s depuis Hamac. Ex: Hamac','Hamac','',20),(154,'Hamac-status','enum2','1,2,3,5,6','Importer les absences valid&eacute;es et en attente de validation ou seulement les absences valid&eacute;es.','Hamac','[[\"1,2,3,5,6\",\"Valid&eacute;es et en attente de validation\"],[\"2\",\"Valid&eacute;es\"]]',30),(155,'Hamac-id','enum2','login','Champ Planning Biblio &agrave; utiliser pour mapper les agents.','Hamac','[[\"login\",\"Login\"],[\"matricule\",\"Matricule\"]]',40),(156,'Conges-Mode','enum2','jours','Décompte des congés en heures ou en jours','Congés','[[\"heures\",\"Heures\"],[\"jours\",\"Jours\"]]',2),(157,'Absences-notifications-B1','checkboxes','[\"2\"]','Destinataires des notifications de nouvelles absences (Circuit B)','Absences','[[0,\"Agents ayant le droit de g&eacute;rer les absences\"],[1,\"Responsables directs\"],[2,\"Cellule planning\"],[3,\"Agent concern&eacute;\"]]',80),(158,'Absences-notifications-B2','checkboxes','[\"2\"]','Destinataires des notifications de modification d&apos;absences (Circuit B)','Absences','[[0,\"Agents ayant le droit de g&eacute;rer les absences\"],[1,\"Responsables directs\"],[2,\"Cellule planning\"],[3,\"Agent concern&eacute;\"]]',90),(159,'Absences-notifications-B3','checkboxes','[\"1\"]','Destinataires des notifications des validations niveau 1 (Circuit B)','Absences','[[0,\"Agents ayant le droit de g&eacute;rer les absences\"],[1,\"Responsables directs\"],[2,\"Cellule planning\"],[3,\"Agent concern&eacute;\"]]',100),(160,'Absences-notifications-B4','checkboxes','[\"3\"]','Destinataires des notifications des validations niveau 2 (Circuit B)','Absences','[[0,\"Agents ayant le droit de g&eacute;rer les absences\"],[1,\"Responsables directs\"],[2,\"Cellule planning\"],[3,\"Agent concern&eacute;\"]]',110),(161,'Absences-DelaiSuppressionDocuments','text','365','Les documents associ&eacute;s aux absences sont supprim&eacute;s au-del&agrave; du nombre de jours d&eacute;finis par ce param&egrave;tre.','Absences','',150),(162,'Conges-demi-journees','boolean','0','Autorise la saisie de congés en demi-journée. Fonctionne uniquement avec le mode de saisie en jour','Congés','',7),(163,'PlanningHebdo-PauseLibre','boolean','1','Ajoute la possibilité de saisir un temps de pause libre dans les heures de présence (Module Planning Hebdo uniquement)','Heures de présence','',65),(165,'Journey-time-between-sites','text','0','Temps de trajet moyen entre sites (en minutes)','Planning','',95),(166,'Journey-time-between-areas','text','0','Temps de trajet moyen entre zones (en minutes)','Planning','',96),(167,'Journey-time-for-absences','text','0','Temps de trajet moyen entre une absence et un poste de service public (en minutes)','Planning','',97),(168,'Conges-fullday-switching-time','text','4','Temps définissant la bascule entre une demi-journée et une journée complète lorsque les crédits de congés sont comptés en jours. Format : entier ou décimal. Exemple : pour 3h30, tapez 3.5','Congés','',7),(169,'Conges-planningVide','boolean','1','Autoriser l\'enregistrement de congés sur des plannings en cours d\'élaboration','Congés','',8),(170,'Conges-apresValidation','boolean','1','Autoriser l\'enregistrement de congés après validation des plannings','Congés','',9),(171,'Conges-validation','boolean','1','Les congés doivent être validés par un administrateur avant d\'être pris en compte','Congés','',3),(172,'Hamac-debug','boolean','0','Active le mode débugage pour l\'importation des absences depuis Hamac. Les informations de débugage sont écrites dans la table \"log\". Attention, si cette option est activée, la taille de la base de données augmente considérablement.','Hamac','',50);
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conges`
--

DROP TABLE IF EXISTS `conges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `perso_id` int(11) NOT NULL,
  `debut` datetime NOT NULL,
  `fin` datetime NOT NULL,
  `halfday` tinyint(4) DEFAULT 0,
  `start_halfday` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `end_halfday` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `commentaires` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refus` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `heures` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debit` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `saisie` timestamp NOT NULL DEFAULT current_timestamp(),
  `saisie_par` int(11) NOT NULL,
  `modif` int(11) NOT NULL DEFAULT 0,
  `modification` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `valide_n1` int(11) NOT NULL DEFAULT 0,
  `validation_n1` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `valide` int(11) NOT NULL DEFAULT 0,
  `validation` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `solde_prec` float DEFAULT NULL,
  `solde_actuel` float DEFAULT NULL,
  `recup_prec` float DEFAULT NULL,
  `recup_actuel` float DEFAULT NULL,
  `reliquat_prec` float DEFAULT NULL,
  `reliquat_actuel` float DEFAULT NULL,
  `anticipation_prec` float DEFAULT NULL,
  `anticipation_actuel` float DEFAULT NULL,
  `supprime` int(11) NOT NULL DEFAULT 0,
  `suppr_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `information` int(11) NOT NULL DEFAULT 0,
  `info_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conges`
--

LOCK TABLES `conges` WRITE;
/*!40000 ALTER TABLE `conges` DISABLE KEYS */;
INSERT INTO `conges` VALUES (1,1,'2020-04-16 00:00:00','2020-04-16 00:00:00',0,'','',NULL,NULL,NULL,NULL,'2020-04-16 10:00:29',0,0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',0,0,0,0,0,0,0,0,0,'0000-00-00 00:00:00',999999999,'2020-04-16 10:00:29');
/*!40000 ALTER TABLE `conges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conges_cet`
--

DROP TABLE IF EXISTS `conges_cet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conges_cet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `perso_id` int(11) NOT NULL,
  `jours` int(11) NOT NULL DEFAULT 0,
  `commentaires` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `saisie` timestamp NOT NULL DEFAULT current_timestamp(),
  `saisie_par` int(11) NOT NULL,
  `modif` int(11) NOT NULL DEFAULT 0,
  `modification` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `valide_n1` int(11) NOT NULL DEFAULT 0,
  `validation_n1` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `valide_n2` int(11) NOT NULL DEFAULT 0,
  `validation_n2` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `refus` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `solde_prec` float DEFAULT NULL,
  `solde_actuel` float DEFAULT NULL,
  `annee` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conges_cet`
--

LOCK TABLES `conges_cet` WRITE;
/*!40000 ALTER TABLE `conges_cet` DISABLE KEYS */;
/*!40000 ALTER TABLE `conges_cet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conges_infos`
--

DROP TABLE IF EXISTS `conges_infos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conges_infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `debut` date DEFAULT NULL,
  `fin` date DEFAULT NULL,
  `texte` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `saisie` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conges_infos`
--

LOCK TABLES `conges_infos` WRITE;
/*!40000 ALTER TABLE `conges_infos` DISABLE KEYS */;
/*!40000 ALTER TABLE `conges_infos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cron`
--

DROP TABLE IF EXISTS `cron`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cron` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `m` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `h` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dom` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mon` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dow` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `command` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comments` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cron`
--

LOCK TABLES `cron` WRITE;
/*!40000 ALTER TABLE `cron` DISABLE KEYS */;
INSERT INTO `cron` VALUES (1,'0','0','*','*','*','planningHebdo/cron.daily.php','Daily Cron for planningHebdo module','2020-04-16 12:00:29'),(2,'0','0','1','1','*','conges/cron.jan1.php','Cron Congés 1er Janvier','2020-04-16 12:00:29'),(3,'0','0','1','9','*','conges/cron.sept1.php','Cron Congés 1er Septembre','2020-04-16 12:00:29');
/*!40000 ALTER TABLE `cron` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edt_samedi`
--

DROP TABLE IF EXISTS `edt_samedi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edt_samedi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `perso_id` int(11) NOT NULL,
  `semaine` date DEFAULT NULL,
  `tableau` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edt_samedi`
--

LOCK TABLES `edt_samedi` WRITE;
/*!40000 ALTER TABLE `edt_samedi` DISABLE KEYS */;
/*!40000 ALTER TABLE `edt_samedi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `heures_absences`
--

DROP TABLE IF EXISTS `heures_absences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `heures_absences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `semaine` date DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `heures` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `heures_absences`
--

LOCK TABLES `heures_absences` WRITE;
/*!40000 ALTER TABLE `heures_absences` DISABLE KEYS */;
/*!40000 ALTER TABLE `heures_absences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `heures_sp`
--

DROP TABLE IF EXISTS `heures_sp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `heures_sp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `semaine` date DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `heures` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `heures_sp`
--

LOCK TABLES `heures_sp` WRITE;
/*!40000 ALTER TABLE `heures_sp` DISABLE KEYS */;
/*!40000 ALTER TABLE `heures_sp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hidden_tables`
--

DROP TABLE IF EXISTS `hidden_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hidden_tables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `perso_id` int(11) NOT NULL DEFAULT 0,
  `tableau` int(11) NOT NULL DEFAULT 0,
  `hidden_tables` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hidden_tables`
--

LOCK TABLES `hidden_tables` WRITE;
/*!40000 ALTER TABLE `hidden_tables` DISABLE KEYS */;
/*!40000 ALTER TABLE `hidden_tables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `infos`
--

DROP TABLE IF EXISTS `infos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `debut` date DEFAULT NULL,
  `fin` date DEFAULT NULL,
  `texte` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `infos`
--

LOCK TABLES `infos` WRITE;
/*!40000 ALTER TABLE `infos` DISABLE KEYS */;
/*!40000 ALTER TABLE `infos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ip_blocker`
--

DROP TABLE IF EXISTS `ip_blocker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ip_blocker` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ip` (`ip`),
  KEY `status` (`status`),
  KEY `timestamp` (`timestamp`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ip_blocker`
--

LOCK TABLES `ip_blocker` WRITE;
/*!40000 ALTER TABLE `ip_blocker` DISABLE KEYS */;
INSERT INTO `ip_blocker` VALUES (1,'127.0.0.1','admin','success','2020-04-16 10:00:29'),(2,'192.168.1.29','admin','success','2020-05-13 14:47:22');
/*!40000 ALTER TABLE `ip_blocker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jours_feries`
--

DROP TABLE IF EXISTS `jours_feries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jours_feries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `annee` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jour` date DEFAULT NULL,
  `ferie` int(1) DEFAULT NULL,
  `fermeture` int(1) DEFAULT NULL,
  `nom` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `commentaire` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jours_feries`
--

LOCK TABLES `jours_feries` WRITE;
/*!40000 ALTER TABLE `jours_feries` DISABLE KEYS */;
/*!40000 ALTER TABLE `jours_feries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lignes`
--

DROP TABLE IF EXISTS `lignes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lignes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lignes`
--

LOCK TABLES `lignes` WRITE;
/*!40000 ALTER TABLE `lignes` DISABLE KEYS */;
INSERT INTO `lignes` VALUES (1,'Magasins'),(2,'Mezzanine'),(3,'Rez de chauss&eacute;e'),(4,'Rez de jardin');
/*!40000 ALTER TABLE `lignes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log`
--

DROP TABLE IF EXISTS `log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `msg` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `program` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log`
--

LOCK TABLES `log` WRITE;
/*!40000 ALTER TABLE `log` DISABLE KEYS */;
/*!40000 ALTER TABLE `log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `niveau1` int(11) NOT NULL,
  `niveau2` int(11) NOT NULL,
  `titre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `condition` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES (1,10,0,'Absences','absences/voir.php',NULL),(2,10,10,'Voir les absences','absences/voir.php',NULL),(3,10,20,'Ajouter une absence','/absence',NULL),(4,10,30,'Informations','/absences/info',NULL),(5,15,0,'Congés','/holiday/index','config=Conges-Enable'),(6,15,10,'Liste des cong&eacute;s','/holiday/index','config=Conges-Enable'),(7,15,15,'Liste des r&eacute;cup&eacute;rations','/holiday/index?recup=1','config=Conges-Enable;Conges-Recuperations'),(8,15,20,'Poser des cong&eacute;s','/holiday/new','config=Conges-Enable'),(9,15,24,'Poser des r&eacute;cup&eacute;rations','conges/recup_pose.php','config=Conges-Enable;Conges-Recuperations'),(10,15,26,'R&eacute;cup&eacute;rations','/comp-time','config=Conges-Enable'),(11,15,30,'Informations','conges/infos.php','config=Conges-Enable'),(12,15,40,'Cr&eacute;dits','conges/credits.php','config=Conges-Enable'),(13,20,0,'Agenda','/calendar',NULL),(14,30,0,'Planning','planning/poste/index.php',NULL),(15,30,90,'Agents volants','planning/volants/index.php','config=Planning-agents-volants'),(16,40,0,'Statistiques','/statistics',NULL),(17,40,10,'Feuille de temps','/statistics/time',NULL),(18,40,20,'Par agent','/statistics/agent',NULL),(19,40,30,'Par poste','statistiques/postes.php',NULL),(20,40,40,'Par poste (Synth&egrave;se)','/statistics/positionsummary',NULL),(21,40,50,'Postes de renfort','/statistics/supportposition',NULL),(22,40,24,'Par service','/statistics/service',NULL),(23,40,60,'Samedis','/statistics/saturday',NULL),(24,40,70,'Absences','/statistics/absence',NULL),(25,40,80,'Pr&eacute;sents / absents','/statistics/attendeesmissing',NULL),(26,40,26,'Par statut','/statistics/status',NULL),(27,50,0,'Administration','/admin',NULL),(28,50,10,'Informations','/admin/info',NULL),(29,50,20,'Les activit&eacute;s','/skill',NULL),(30,50,30,'Les agents','/agent',NULL),(31,50,40,'Les postes','/position',NULL),(32,50,50,'Les mod&egrave;les','/model',NULL),(33,50,60,'Les tableaux','/framework',NULL),(34,50,70,'Jours de fermeture','/closingday',NULL),(35,50,75,'Heures de présence','/workinghour','config=PlanningHebdo'),(36,50,77,'Notifications / Validations','/notification','config=Absences-notifications-agent-par-agent'),(37,50,80,'Configuration','/config',NULL),(38,60,0,'Aide','/help',NULL);
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personnel`
--

DROP TABLE IF EXISTS `personnel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personnel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `prenom` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `mail` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `statut` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `categorie` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `service` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `arrivee` date NOT NULL DEFAULT '0000-00-00',
  `depart` date NOT NULL DEFAULT '0000-00-00',
  `postes` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `actif` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'true',
  `droits` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `commentaires` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `heures_hebdo` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `heures_travail` float NOT NULL,
  `sites` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `temps` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `informations` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `recup` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `supprime` enum('0','1','2') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `mails_responsables` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `matricule` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `code_ics` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url_ics` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `check_ics` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT '[1,1,1]',
  `check_hamac` int(1) NOT NULL DEFAULT 1,
  `conges_credit` float DEFAULT NULL,
  `conges_reliquat` float DEFAULT NULL,
  `conges_anticipation` float DEFAULT NULL,
  `comp_time` float DEFAULT NULL,
  `conges_annuel` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personnel`
--

LOCK TABLES `personnel` WRITE;
/*!40000 ALTER TABLE `personnel` DISABLE KEYS */;
INSERT INTO `personnel` VALUES (1,'admin','admin','admin@example.com','','','','0000-00-00','0000-00-00','','Inactif','[\"6\",\"201\",\"501\",\"701\",\"3\",\"4\",\"21\",\"1101\",\"1201\",\"301\",\"1001\",\"901\",\"801\",\"22\",\"5\",\"17\",\"1301\",\"25\",\"23\",6,9,99,100,20]','admin','e2bb2a6036c4bc9adb758f8f70ba79d6','Compte cr&eacute;&eacute; lors de l&apos;installation du planning','2020-05-13 16:47:22','0',0,'','[[\"\",\"\",\"\",\"\"],[\"\",\"\",\"\",\"\"],[\"\",\"\",\"\",\"\"],[\"\",\"\",\"\",\"\"],[\"\",\"\",\"\",\"\"],[\"\",\"\",\"\",\"\"]]','','','0','','',NULL,NULL,'[0,0,0]',0,NULL,NULL,0,0,NULL),(2,'Tout le monde','','','','','','0000-00-00','0000-00-00','','Actif','[99,100]','','','Compte cr&eacute;&eacute; lors de l&apos;installation du planning','0000-00-00 00:00:00','',0,'','[[\"09:00:00\",\"12:00:00\",\"13:00:00\",\"17:00:00\"],[\"09:00:00\",\"12:00:00\",\"13:00:00\",\"17:00:00\"],[\"09:00:00\",\"12:00:00\",\"13:00:00\",\"17:00:00\"],[\"09:00:00\",\"12:00:00\",\"13:00:00\",\"17:00:00\"],[\"09:00:00\",\"12:00:00\",\"13:00:00\",\"17:00:00\"],[\"\",\"\",\"\",\"\"]]','','','0','','',NULL,NULL,'[1,1,1]',1,NULL,NULL,0,0,NULL);
/*!40000 ALTER TABLE `personnel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl_notes`
--

DROP TABLE IF EXISTS `pl_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `site` int(3) NOT NULL DEFAULT 1,
  `text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `perso_id` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl_notes`
--

LOCK TABLES `pl_notes` WRITE;
/*!40000 ALTER TABLE `pl_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `pl_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl_notifications`
--

DROP TABLE IF EXISTS `pl_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site` int(2) NOT NULL DEFAULT 1,
  `update_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `data` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `site` (`site`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl_notifications`
--

LOCK TABLES `pl_notifications` WRITE;
/*!40000 ALTER TABLE `pl_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `pl_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl_poste`
--

DROP TABLE IF EXISTS `pl_poste`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl_poste` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `perso_id` int(11) NOT NULL DEFAULT 0,
  `date` date NOT NULL DEFAULT '0000-00-00',
  `poste` int(11) NOT NULL DEFAULT 0,
  `absent` enum('0','1','2') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `chgt_login` int(4) DEFAULT NULL,
  `chgt_time` datetime NOT NULL,
  `debut` time NOT NULL,
  `fin` time NOT NULL,
  `supprime` enum('0','1') COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `site` int(3) DEFAULT 1,
  `grise` enum('0','1') COLLATE utf8mb4_unicode_ci DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `site` (`site`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl_poste`
--

LOCK TABLES `pl_poste` WRITE;
/*!40000 ALTER TABLE `pl_poste` DISABLE KEYS */;
/*!40000 ALTER TABLE `pl_poste` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl_poste_cellules`
--

DROP TABLE IF EXISTS `pl_poste_cellules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl_poste_cellules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero` int(11) NOT NULL,
  `tableau` int(11) NOT NULL,
  `ligne` int(11) NOT NULL,
  `colonne` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl_poste_cellules`
--

LOCK TABLES `pl_poste_cellules` WRITE;
/*!40000 ALTER TABLE `pl_poste_cellules` DISABLE KEYS */;
INSERT INTO `pl_poste_cellules` VALUES (1,1,1,0,1),(2,1,1,0,9),(3,1,1,1,1),(4,1,1,1,9),(5,1,1,3,1),(6,1,1,4,1),(7,1,1,6,1),(8,1,1,7,1),(9,1,1,7,9),(10,1,1,8,1),(11,1,1,8,9),(12,1,1,9,1),(13,1,1,9,9),(14,1,1,10,1),(15,1,1,10,9),(16,1,1,11,1),(17,1,1,11,9),(18,1,1,12,1),(19,1,1,14,1),(20,1,1,15,1),(21,1,1,15,9),(22,1,1,16,1),(23,1,1,16,9),(24,1,1,17,1),(25,1,1,17,9),(26,1,1,18,1),(27,1,1,18,9),(28,1,1,19,1),(29,1,1,19,9),(30,1,1,20,1),(31,1,1,20,9),(32,1,1,21,1),(33,1,1,21,9),(34,1,1,22,1),(35,1,1,22,9),(36,1,1,23,1),(37,1,1,23,8),(38,1,1,23,9),(39,1,2,0,1),(40,1,2,0,4),(41,1,3,0,12),(42,1,3,1,12),(43,1,3,2,12),(44,1,3,3,12),(45,1,3,4,12),(46,1,3,5,12),(47,1,3,6,12),(48,1,3,7,12),(49,1,3,8,12),(50,1,3,9,12),(51,1,3,10,12);
/*!40000 ALTER TABLE `pl_poste_cellules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl_poste_horaires`
--

DROP TABLE IF EXISTS `pl_poste_horaires`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl_poste_horaires` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `debut` time NOT NULL DEFAULT '00:00:00',
  `fin` time NOT NULL DEFAULT '00:00:00',
  `tableau` int(11) NOT NULL,
  `numero` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl_poste_horaires`
--

LOCK TABLES `pl_poste_horaires` WRITE;
/*!40000 ALTER TABLE `pl_poste_horaires` DISABLE KEYS */;
INSERT INTO `pl_poste_horaires` VALUES (1,'09:00:00','10:00:00',1,1),(2,'10:00:00','11:30:00',1,1),(3,'11:30:00','13:00:00',1,1),(4,'13:00:00','14:30:00',1,1),(5,'14:30:00','16:00:00',1,1),(6,'16:00:00','17:30:00',1,1),(7,'17:30:00','19:00:00',1,1),(8,'19:00:00','20:00:00',1,1),(9,'20:00:00','22:00:00',1,1),(10,'09:00:00','14:00:00',2,1),(11,'14:00:00','16:00:00',2,1),(12,'16:00:00','18:00:00',2,1),(13,'18:00:00','22:00:00',2,1),(14,'09:00:00','10:00:00',3,1),(15,'10:00:00','11:00:00',3,1),(16,'11:00:00','12:00:00',3,1),(17,'12:00:00','13:00:00',3,1),(18,'13:00:00','14:00:00',3,1),(19,'14:00:00','15:00:00',3,1),(20,'15:00:00','16:00:00',3,1),(21,'16:00:00','17:00:00',3,1),(22,'17:00:00','18:00:00',3,1),(23,'18:00:00','19:00:00',3,1),(24,'19:00:00','20:00:00',3,1),(25,'20:00:00','22:00:00',3,1);
/*!40000 ALTER TABLE `pl_poste_horaires` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl_poste_lignes`
--

DROP TABLE IF EXISTS `pl_poste_lignes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl_poste_lignes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero` int(11) NOT NULL,
  `tableau` int(11) NOT NULL,
  `ligne` int(11) NOT NULL,
  `poste` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('poste','ligne','titre','classe') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl_poste_lignes`
--

LOCK TABLES `pl_poste_lignes` WRITE;
/*!40000 ALTER TABLE `pl_poste_lignes` DISABLE KEYS */;
INSERT INTO `pl_poste_lignes` VALUES (1,1,1,0,'24','poste'),(2,1,1,1,'36','poste'),(3,1,1,2,'3','ligne'),(4,1,1,3,'4','poste'),(5,1,1,4,'5','poste'),(6,1,1,6,'6','poste'),(7,1,1,7,'7','poste'),(8,1,1,8,'8','poste'),(9,1,1,9,'9','poste'),(10,1,1,10,'10','poste'),(11,1,1,11,'11','poste'),(12,1,1,12,'12','poste'),(13,1,1,13,'4','ligne'),(14,1,1,15,'13','poste'),(15,1,1,16,'14','poste'),(16,1,1,17,'15','poste'),(17,1,1,18,'16','poste'),(18,1,1,19,'17','poste'),(19,1,1,20,'19','poste'),(20,1,1,21,'20','poste'),(21,1,1,22,'21','poste'),(22,1,1,23,'22','poste'),(23,1,1,0,'Mezzanine','titre'),(24,1,2,0,'23','poste'),(25,1,2,0,'R&eacute;serve','titre'),(26,1,3,0,'28','poste'),(27,1,3,1,'25','poste'),(28,1,3,2,'26','poste'),(29,1,3,3,'27','poste'),(30,1,3,4,'29','poste'),(31,1,3,5,'30','poste'),(32,1,3,6,'31','poste'),(33,1,3,7,'32','poste'),(34,1,3,8,'33','poste'),(35,1,3,9,'34','poste'),(36,1,3,10,'35','poste'),(37,1,3,0,'Rangement','titre');
/*!40000 ALTER TABLE `pl_poste_lignes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl_poste_modeles`
--

DROP TABLE IF EXISTS `pl_poste_modeles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl_poste_modeles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model_id` int(11) NOT NULL DEFAULT 0,
  `perso_id` int(11) NOT NULL,
  `poste` int(11) NOT NULL,
  `commentaire` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `debut` time NOT NULL,
  `fin` time NOT NULL,
  `tableau` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jour` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `site` int(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl_poste_modeles`
--

LOCK TABLES `pl_poste_modeles` WRITE;
/*!40000 ALTER TABLE `pl_poste_modeles` DISABLE KEYS */;
/*!40000 ALTER TABLE `pl_poste_modeles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl_poste_modeles_tab`
--

DROP TABLE IF EXISTS `pl_poste_modeles_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl_poste_modeles_tab` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` int(11) NOT NULL DEFAULT 0,
  `jour` int(11) NOT NULL,
  `tableau` int(11) NOT NULL,
  `site` int(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl_poste_modeles_tab`
--

LOCK TABLES `pl_poste_modeles_tab` WRITE;
/*!40000 ALTER TABLE `pl_poste_modeles_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `pl_poste_modeles_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl_poste_tab`
--

DROP TABLE IF EXISTS `pl_poste_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl_poste_tab` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tableau` int(20) NOT NULL,
  `nom` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `site` int(2) NOT NULL DEFAULT 1,
  `supprime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl_poste_tab`
--

LOCK TABLES `pl_poste_tab` WRITE;
/*!40000 ALTER TABLE `pl_poste_tab` DISABLE KEYS */;
INSERT INTO `pl_poste_tab` VALUES (1,1,'Tableau 1',1,NULL);
/*!40000 ALTER TABLE `pl_poste_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl_poste_tab_affect`
--

DROP TABLE IF EXISTS `pl_poste_tab_affect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl_poste_tab_affect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `tableau` int(11) NOT NULL,
  `site` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl_poste_tab_affect`
--

LOCK TABLES `pl_poste_tab_affect` WRITE;
/*!40000 ALTER TABLE `pl_poste_tab_affect` DISABLE KEYS */;
/*!40000 ALTER TABLE `pl_poste_tab_affect` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl_poste_tab_grp`
--

DROP TABLE IF EXISTS `pl_poste_tab_grp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl_poste_tab_grp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lundi` int(11) DEFAULT NULL,
  `mardi` int(11) DEFAULT NULL,
  `mercredi` int(11) DEFAULT NULL,
  `jeudi` int(11) DEFAULT NULL,
  `vendredi` int(11) DEFAULT NULL,
  `samedi` int(11) DEFAULT NULL,
  `dimanche` int(11) DEFAULT NULL,
  `site` int(2) NOT NULL DEFAULT 1,
  `supprime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl_poste_tab_grp`
--

LOCK TABLES `pl_poste_tab_grp` WRITE;
/*!40000 ALTER TABLE `pl_poste_tab_grp` DISABLE KEYS */;
/*!40000 ALTER TABLE `pl_poste_tab_grp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl_poste_verrou`
--

DROP TABLE IF EXISTS `pl_poste_verrou`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl_poste_verrou` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL DEFAULT '0000-00-00',
  `verrou` int(1) NOT NULL DEFAULT 0,
  `validation` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `perso` int(11) NOT NULL DEFAULT 0,
  `verrou2` int(1) NOT NULL DEFAULT 0,
  `validation2` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `perso2` int(11) NOT NULL DEFAULT 0,
  `vivier` int(1) NOT NULL DEFAULT 0,
  `site` int(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl_poste_verrou`
--

LOCK TABLES `pl_poste_verrou` WRITE;
/*!40000 ALTER TABLE `pl_poste_verrou` DISABLE KEYS */;
/*!40000 ALTER TABLE `pl_poste_verrou` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `planning_hebdo`
--

DROP TABLE IF EXISTS `planning_hebdo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `planning_hebdo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `perso_id` int(11) NOT NULL,
  `debut` date NOT NULL,
  `fin` date NOT NULL,
  `temps` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `breaktime` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `saisie` timestamp NOT NULL DEFAULT current_timestamp(),
  `modif` int(11) NOT NULL DEFAULT 0,
  `modification` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `valide_n1` int(11) NOT NULL DEFAULT 0,
  `validation_n1` timestamp NULL DEFAULT NULL,
  `valide` int(11) NOT NULL DEFAULT 0,
  `validation` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `actuel` int(1) NOT NULL DEFAULT 0,
  `remplace` int(11) NOT NULL DEFAULT 0,
  `cle` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exception` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cle` (`cle`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `planning_hebdo`
--

LOCK TABLES `planning_hebdo` WRITE;
/*!40000 ALTER TABLE `planning_hebdo` DISABLE KEYS */;
/*!40000 ALTER TABLE `planning_hebdo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `postes`
--

DROP TABLE IF EXISTS `postes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `postes` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `nom` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `groupe` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `groupe_id` int(11) NOT NULL DEFAULT 0,
  `obligatoire` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `etage` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `activites` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `statistiques` enum('0','1') COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `teleworking` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `bloquant` enum('0','1') COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `site` int(1) DEFAULT 1,
  `categories` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supprime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `postes`
--

LOCK TABLES `postes` WRITE;
/*!40000 ALTER TABLE `postes` DISABLE KEYS */;
INSERT INTO `postes` VALUES (4,'Inscription 1','',0,'Obligatoire','RDC','[5,9]','1','0','1',1,NULL,NULL),(5,'Retour','',0,'Obligatoire','RDC','[6,9]','1','0','1',1,NULL,NULL),(6,'Prêt / retour 1','',0,'Obligatoire','RDC','[7,6,9]','1','0','1',1,NULL,NULL),(7,'Prêt / retour 2','',0,'Renfort','RDC','[7,6,9]','1','0','1',1,NULL,NULL),(8,'Prêt / retour 3','',0,'Renfort','RDC','[5,7,6,9]','1','0','1',1,NULL,NULL),(9,'Prêt / retour 4','',0,'Renfort','RDC','[7,6,9]','1','0','1',1,NULL,NULL),(10,'Inscription 2','',0,'Renfort','RDC','[5]','1','0','1',1,NULL,NULL),(11,'Communication RDC','',0,'Renfort','RDC','[3,7,9]','1','0','1',1,NULL,NULL),(12,'Renseignement RDC','',0,'Obligatoire','RDC','[9,10]','1','0','1',1,NULL,NULL),(13,'Renseignement spécialisé 1','',0,'Obligatoire','RDJ','[9,10,12]','1','0','1',1,NULL,NULL),(14,'Renseignement spécialisé 2','',0,'Renfort','RDJ','[9,10,12]','1','0','1',1,NULL,NULL),(15,'Renseignement spécialisé 3','',0,'Renfort','RDJ','[9,10,12]','1','0','1',1,NULL,NULL),(16,'Communication (banque 1)','',0,'Obligatoire','RDJ','[3,7,6,9]','1','0','1',1,NULL,NULL),(17,'Communication (banque 2)','',0,'Renfort','RDJ','[3,9,10]','1','0','1',1,NULL,NULL),(19,'Communication (coordination)','',0,'Obligatoire','RDJ','[3]','1','0','1',1,NULL,NULL),(20,'Communication (magasin 1)','',0,'Obligatoire','RDJ','[3]','1','0','1',1,NULL,NULL),(21,'Communication (magasin 2)','',0,'Obligatoire','RDJ','[11]','1','0','1',1,NULL,NULL),(22,'Communication (magasin 3)','',0,'Renfort','RDJ','[3]','1','0','1',1,NULL,NULL),(23,'Consultation de la réserve','',0,'Obligatoire','RDJ','[4,9]','1','0','1',1,NULL,NULL),(24,'Audiovisuel et autoformation','',0,'Obligatoire','Mezzanine','[1,2,7,9]','1','0','1',1,NULL,NULL),(25,'Rangement 2','',0,'Obligatoire','RDC','[8]','1','0','1',1,NULL,NULL),(26,'Rangement 3','',0,'Obligatoire','RDC','[8]','1','0','1',1,NULL,NULL),(27,'Rangement 4','',0,'Renfort','RDC','[8]','1','0','1',1,NULL,NULL),(28,'Rangement 1','',0,'Obligatoire','Mezzanine','[8]','1','0','1',1,NULL,NULL),(29,'Rangement 5','',0,'Obligatoire','RDJ','[8]','1','0','1',1,NULL,NULL),(30,'Rangement 6','',0,'Obligatoire','RDJ','[8]','1','0','1',1,NULL,NULL),(31,'Rangement 7','',0,'Renfort','RDJ','[8]','1','0','1',1,NULL,NULL),(32,'Rangement 8','',0,'Renfort','RDJ','[8]','1','0','1',1,NULL,NULL),(33,'Rangement 9','',0,'Renfort','RDJ','[8]','1','0','1',1,NULL,NULL),(34,'Rangement 10','',0,'Obligatoire','Magasins','[8]','1','0','1',1,NULL,NULL),(35,'Rangement 11','',0,'Obligatoire','Magasins','[8]','1','0','1',1,NULL,NULL),(36,'Renseignement kiosque','',0,'Renfort','Mezzanine','[9,10]','1','0','1',1,NULL,NULL);
/*!40000 ALTER TABLE `postes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recuperations`
--

DROP TABLE IF EXISTS `recuperations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recuperations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `perso_id` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `date2` date DEFAULT NULL,
  `heures` float DEFAULT NULL,
  `etat` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `commentaires` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `saisie` timestamp NOT NULL DEFAULT current_timestamp(),
  `saisie_par` int(11) NOT NULL,
  `modif` int(11) NOT NULL DEFAULT 0,
  `modification` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `valide_n1` int(11) NOT NULL DEFAULT 0,
  `validation_n1` datetime DEFAULT NULL,
  `valide` int(11) NOT NULL DEFAULT 0,
  `validation` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `refus` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `solde_prec` float DEFAULT NULL,
  `solde_actuel` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recuperations`
--

LOCK TABLES `recuperations` WRITE;
/*!40000 ALTER TABLE `recuperations` DISABLE KEYS */;
/*!40000 ALTER TABLE `recuperations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `responsables`
--

DROP TABLE IF EXISTS `responsables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `responsables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `perso_id` int(11) NOT NULL DEFAULT 0,
  `responsable` int(11) NOT NULL DEFAULT 0,
  `notification` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `responsables`
--

LOCK TABLES `responsables` WRITE;
/*!40000 ALTER TABLE `responsables` DISABLE KEYS */;
/*!40000 ALTER TABLE `responsables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `select_abs`
--

DROP TABLE IF EXISTS `select_abs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `select_abs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `valeur` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `rang` int(11) NOT NULL DEFAULT 0,
  `type` int(1) NOT NULL DEFAULT 0,
  `notification_workflow` char(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `teleworking` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `select_abs`
--

LOCK TABLES `select_abs` WRITE;
/*!40000 ALTER TABLE `select_abs` DISABLE KEYS */;
INSERT INTO `select_abs` VALUES (1,'Non justifiée',1,0,'A',0),(2,'Congés payés',2,0,'A',0),(3,'Maladie',3,0,'A',0),(4,'Congé maternité',4,0,'A',0),(5,'Télétravail',5,0,'A',1),(6,'Réunion syndicale',6,0,'A',0),(7,'Grève',7,0,'A',0),(8,'Formation',8,0,'A',0),(9,'Concours',9,0,'A',0),(10,'Stage',10,0,'A',0),(11,'Réunion',11,0,'A',0),(12,'Entretien',12,0,'A',0),(13,'Autre',13,0,'A',0);
/*!40000 ALTER TABLE `select_abs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `select_categories`
--

DROP TABLE IF EXISTS `select_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `select_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `valeur` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `rang` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `select_categories`
--

LOCK TABLES `select_categories` WRITE;
/*!40000 ALTER TABLE `select_categories` DISABLE KEYS */;
INSERT INTO `select_categories` VALUES (1,'Cat&eacute;gorie A',10),(2,'Cat&eacute;gorie B',20),(3,'Cat&eacute;gorie C',30);
/*!40000 ALTER TABLE `select_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `select_etages`
--

DROP TABLE IF EXISTS `select_etages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `select_etages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `valeur` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `rang` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `select_etages`
--

LOCK TABLES `select_etages` WRITE;
/*!40000 ALTER TABLE `select_etages` DISABLE KEYS */;
INSERT INTO `select_etages` VALUES (1,'Mezzanine',1),(2,'RDC',2),(3,'RDJ',3),(4,'Magasins',4);
/*!40000 ALTER TABLE `select_etages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `select_groupes`
--

DROP TABLE IF EXISTS `select_groupes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `select_groupes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `valeur` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `rang` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `select_groupes`
--

LOCK TABLES `select_groupes` WRITE;
/*!40000 ALTER TABLE `select_groupes` DISABLE KEYS */;
/*!40000 ALTER TABLE `select_groupes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `select_services`
--

DROP TABLE IF EXISTS `select_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `select_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `valeur` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `rang` int(11) NOT NULL,
  `couleur` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `select_services`
--

LOCK TABLES `select_services` WRITE;
/*!40000 ALTER TABLE `select_services` DISABLE KEYS */;
INSERT INTO `select_services` VALUES (1,'P&ocirc;le public',1,''),(2,'P&ocirc;le conservation',2,''),(3,'P&ocirc;le collection',3,''),(4,'P&ocirc;le informatique',4,''),(5,'P&ocirc;le administratif',5,''),(6,'Direction',6,'');
/*!40000 ALTER TABLE `select_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `select_statuts`
--

DROP TABLE IF EXISTS `select_statuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `select_statuts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `valeur` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `rang` int(11) NOT NULL DEFAULT 0,
  `couleur` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `categorie` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `select_statuts`
--

LOCK TABLES `select_statuts` WRITE;
/*!40000 ALTER TABLE `select_statuts` DISABLE KEYS */;
INSERT INTO `select_statuts` VALUES (1,'Conservateur',1,'',1),(2,'Biblioth&eacute;caire',2,'',1),(3,'AB',3,'',0),(4,'BAS',4,'',2),(5,'Magasinier',5,'',3),(6,'Etudiant',6,'',3),(7,'Garde de nuit',7,'',0),(8,'Autre',8,'',0);
/*!40000 ALTER TABLE `select_statuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volants`
--

DROP TABLE IF EXISTS `volants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `perso_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volants`
--

LOCK TABLES `volants` WRITE;
/*!40000 ALTER TABLE `volants` DISABLE KEYS */;
/*!40000 ALTER TABLE `volants` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-23 12:11:16
