-- MariaDB dump 10.19  Distrib 10.6.17-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: planno
-- ------------------------------------------------------
-- Server version	10.6.17-MariaDB-1:10.6.17+maria~ubu2004

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `absence_blocks`
--

DROP TABLE IF EXISTS `absence_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `absence_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `start` date NOT NULL DEFAULT '0000-00-00',
  `end` date NOT NULL DEFAULT '0000-00-00',
  `comment` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `absence_blocks`
--

LOCK TABLES `absence_blocks` WRITE;
/*!40000 ALTER TABLE `absence_blocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `absence_blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `absences`
--

DROP TABLE IF EXISTS `absences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `absences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `perso_id` int(11) NOT NULL DEFAULT 0,
  `debut` datetime NOT NULL,
  `fin` datetime NOT NULL,
  `motif` text NOT NULL,
  `motif_autre` text NOT NULL,
  `commentaires` text NOT NULL,
  `etat` text NOT NULL,
  `demande` datetime NOT NULL,
  `valide` int(11) NOT NULL DEFAULT 0,
  `validation` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `valide_n1` int(11) NOT NULL DEFAULT 0,
  `validation_n1` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pj1` int(1) DEFAULT 0,
  `pj2` int(1) DEFAULT 0,
  `so` int(1) DEFAULT 0,
  `groupe` varchar(14) DEFAULT NULL,
  `cal_name` varchar(300) NOT NULL,
  `ical_key` text NOT NULL,
  `last_modified` varchar(255) DEFAULT NULL,
  `uid` text DEFAULT NULL,
  `rrule` text DEFAULT NULL,
  `id_origin` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `cal_name` (`cal_name`(250)),
  KEY `perso_id` (`perso_id`),
  KEY `debut` (`debut`),
  KEY `fin` (`fin`),
  KEY `groupe` (`groupe`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `absences`
--

LOCK TABLES `absences` WRITE;
/*!40000 ALTER TABLE `absences` DISABLE KEYS */;
/*!40000 ALTER TABLE `absences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `absences_documents`
--

DROP TABLE IF EXISTS `absences_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `absences_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `absence_id` int(11) NOT NULL,
  `filename` text NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `absences_documents`
--

LOCK TABLES `absences_documents` WRITE;
/*!40000 ALTER TABLE `absences_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `absences_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `absences_infos`
--

DROP TABLE IF EXISTS `absences_infos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `absences_infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `debut` date DEFAULT NULL,
  `fin` date DEFAULT NULL,
  `texte` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `absences_infos`
--

LOCK TABLES `absences_infos` WRITE;
/*!40000 ALTER TABLE `absences_infos` DISABLE KEYS */;
/*!40000 ALTER TABLE `absences_infos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `absences_recurrentes`
--

DROP TABLE IF EXISTS `absences_recurrentes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `absences_recurrentes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(50) DEFAULT NULL,
  `perso_id` int(11) DEFAULT NULL,
  `event` text DEFAULT NULL,
  `end` enum('0','1') NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_update` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_check` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `perso_id` (`perso_id`),
  KEY `end` (`end`),
  KEY `last_check` (`last_check`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `absences_recurrentes`
--

LOCK TABLES `absences_recurrentes` WRITE;
/*!40000 ALTER TABLE `absences_recurrentes` DISABLE KEYS */;
/*!40000 ALTER TABLE `absences_recurrentes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acces`
--

DROP TABLE IF EXISTS `acces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `acces` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` text NOT NULL,
  `groupe_id` int(11) NOT NULL,
  `groupe` text NOT NULL,
  `page` varchar(50) NOT NULL,
  `ordre` int(2) NOT NULL DEFAULT 0,
  `categorie` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acces`
--

LOCK TABLES `acces` WRITE;
/*!40000 ALTER TABLE `acces` DISABLE KEYS */;
INSERT INTO `acces` VALUES (96,'Planning Poste',301,'Création / modification des plannings, utilisation et gestion des modèles','',110,'Planning'),(9,'Personnel - Password',100,'','personnel/password.php',0,''),(15,'Absences - Infos',201,'Gestion des absences, validation niveau 1','',30,'Absences'),(16,'Personnel - Index',4,'Voir les fiches des agents','',60,'Agents'),(18,'Postes et activités',5,'Gestion des postes','',160,'Postes'),(24,'Statistiques',17,'Accès aux statistiques','',170,'Statistiques'),(32,'Liste des agents présents et absents',1301,'Accès aux statistiques Présents / Absents','',171,'Statistiques'),(33,'Configuration avancée',20,'Configuration avancée','',0,''),(35,'Personnel - Valid',21,'Gestion des agents','',70,'Agents'),(36,'Gestion du personnel',21,'Gestion des agents','',70,'Agents'),(38,'Configuration des horaires des tableaux',22,'Configuration des tableaux','planning/postes_cfg/horaires.php',140,'Planning'),(39,'Configuration des horaires des tableaux',22,'Configuration des tableaux','',140,'Planning'),(40,'Configuration des lignes des tableaux',22,'Configuration des tableaux','planning/postes_cfg/lignes.php',140,'Planning'),(43,'Activités - Validation',5,'Gestion des postes','activites/valid.php',160,'Postes'),(48,'Configuration des tableaux - Modif',22,'Configuration des tableaux','',140,'Planning'),(49,'Informations',23,'Informations','',0,''),(53,'Configuration des tableaux - Modif',22,'Configuration des tableaux','',140,'Planning'),(54,'Configuration des tableaux - Modif',22,'Configuration des tableaux','',140,'Planning'),(55,'Configuration des tableaux - Modif',22,'Configuration des tableaux','',140,'Planning'),(56,'Modification des plannings - menudiv',1001,'Modification des plannings','planning/poste/menudiv.php',120,'Planning'),(57,'Modification des plannings - majdb',1001,'Modification des plannings','planning/poste/majdb.php',120,'Planning'),(59,'Jours fériés',25,'Gestion des jours fériés','',0,''),(61,'Voir les agendas de tous',3,'Voir les agendas de tous','',55,'Agendas'),(62,'Modifier ses propres absences',6,'Modifier ses propres absences','',20,'Absences'),(64,'Gestion des absences, validation niveau 2',501,'Gestion des absences, validation niveau 2','',40,'Absences'),(66,'Gestion des absences, pièces justificatives',701,'Gestion des absences, pièces justificatives','',50,'Absences'),(67,'Planning Hebdo - Admin N1',1101,'Gestion des heures de présence, validation niveau 1','',80,'Heures de présence'),(73,'Planning Hebdo - Admin N2',1201,'Gestion des heures de présence, validation niveau 2','',90,'Heures de présence'),(74,'Modification des commentaires des plannings',801,'Modification des commentaires des plannings','',130,'Planning'),(75,'Griser les cellules des plannings',901,'Griser les cellules des plannings','',125,'Planning'),(78,'Congés - Index',100,'','conges/index.php',0,''),(82,'Gestion des congés, validation niveau 2',601,'Gestion des congés, validation niveau 2','',76,'Congés'),(86,'Gestion des congés, validation niveau 1',401,'Gestion des congés, validation niveau 1','',75,'Congés'),(93,'Enregistrement d\'absences pour plusieurs agents',9,'Enregistrement d\'absences pour plusieurs agents','',25,'Absences');
/*!40000 ALTER TABLE `acces` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activites`
--

DROP TABLE IF EXISTS `activites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` text NOT NULL,
  `supprime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activites`
--

LOCK TABLES `activites` WRITE;
/*!40000 ALTER TABLE `activites` DISABLE KEYS */;
INSERT INTO `activites` VALUES (1,'Assistance audiovisuel','2024-02-22 10:19:40'),(2,'Assistance autoformation','2024-02-22 10:19:42'),(3,'Communication','2024-02-22 10:19:43'),(4,'Communication réserve','2024-02-22 10:19:45'),(5,'Inscription','2024-02-22 10:19:46'),(6,'Prêt/retour de document','2024-02-22 10:19:49'),(7,'Prêt de matériel','2024-02-22 10:19:48'),(8,'Rangement','2024-02-22 10:19:51'),(9,'Renseignement','2024-02-22 10:19:53'),(10,'Renseignement bibliographique','2024-02-22 10:19:51'),(11,'Renseignement réserve','2024-02-22 10:19:48'),(12,'Renseignement spécialisé','2024-02-22 10:19:46'),(13,'Inscription',NULL),(14,'Prêt - retour',NULL),(15,'Rangement',NULL),(16,'Accueil',NULL),(17,'Animation',NULL);
/*!40000 ALTER TABLE `activites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appel_dispo`
--

DROP TABLE IF EXISTS `appel_dispo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appel_dispo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site` int(11) NOT NULL DEFAULT 1,
  `poste` int(11) NOT NULL DEFAULT 0,
  `date` varchar(10) DEFAULT NULL,
  `debut` varchar(8) DEFAULT NULL,
  `fin` varchar(8) DEFAULT NULL,
  `destinataires` text DEFAULT NULL,
  `sujet` text DEFAULT NULL,
  `message` text DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appel_dispo`
--

LOCK TABLES `appel_dispo` WRITE;
/*!40000 ALTER TABLE `appel_dispo` DISABLE KEYS */;
/*!40000 ALTER TABLE `appel_dispo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL,
  `valeur` text NOT NULL,
  `commentaires` text NOT NULL,
  `categorie` varchar(100) NOT NULL,
  `valeurs` text NOT NULL,
  `extra` varchar(100) DEFAULT NULL,
  `ordre` int(2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nom` (`nom`)
) ENGINE=MyISAM AUTO_INCREMENT=205 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES (1,'Version','info','24.04.00','Version de l&apos;application',' Divers','',NULL,0),(2,'URL','info','http://planno','URL de l&apos;application',' Divers','',NULL,10),(3,'Mail-IsEnabled','boolean','1','Active ou d&eacute;sactive l&apos;envoi des mails','Messagerie','',NULL,10),(4,'toutlemonde','boolean','0','Affiche ou non l&apos;utilisateur \"tout le monde\" dans le menu.','Planning','',NULL,5),(5,'Mail-IsMail-IsSMTP','enum','IsMail','Classe &agrave; utiliser : SMTP, fonction PHP IsMail','Messagerie','IsSMTP,IsMail','onchange=\'mail_config();\'',10),(185,'Conges-Heures','enum2','0','Permettre la saisie de congés sur quelques heures ou forcer la saisie de congés sur des journées complètes. Paramètre actif avec les options Conges-Mode=Heures et Conges-Recuperations=Dissocier','Congés','[[0,\"Forcer la saisie de congés sur journées entières\"],[1,\"Permettre la saisie de congés sur quelques heures\"]]',NULL,3),(7,'Mail-Hostname','','','Nom d\'h&ocirc;te du serveur pour l&apos;envoi des mails.','Messagerie','',NULL,10),(8,'Mail-Host','','localhost','Nom FQDN ou IP du serveur SMTP.','Messagerie','',NULL,10),(9,'Mail-Port','','25','Port du serveur SMTP','Messagerie','',NULL,10),(10,'Mail-SMTPSecure','enum','','Cryptage utilis&eacute; par le serveur STMP.','Messagerie',',ssl,tls',NULL,10),(11,'Mail-SMTPAuth','boolean','0','Le serveur SMTP requiert-il une authentification?','Messagerie','',NULL,10),(12,'Mail-Username','','','Nom d&apos;utilisateur pour le serveur SMTP.','Messagerie','',NULL,10),(13,'Mail-Password','password','::3427fb54e1562edf827c001a82ebe5c0','Mot de passe pour le serveur SMTP','Messagerie','',NULL,10),(14,'Mail-From','','notifications-planno@biblibre.com','Adresse email de l&apos;expediteur.','Messagerie','',NULL,10),(15,'Mail-FromName','','Planno','Nom de l&apos;expediteur.','Messagerie','',NULL,10),(16,'Mail-Signature','textarea','Ce message a été envoyé par Planno.\r\nMerci de ne pas y répondre.','Signature des e-mails','Messagerie','',NULL,10),(17,'Dimanche','boolean','0','Utiliser le planning le dimanche',' Divers','',NULL,20),(18,'nb_semaine','enum','1','Nombre de semaines pour la rotation des heures de présence. Les valeurs supérieures à 3 ne peuvent être utilisées que si le paramètre PlanningHebdo est coché','Heures de présence','1,2,3,4,5,6,7,8,9,10',NULL,0),(19,'dateDebutPlHebdo','date','','Date de début permettant la rotation des heures de présence (pour l\'utilisation de 3 plannings hebdomadaires. Format JJ/MM/AAAA)','Heures de présence','',NULL,0),(20,'ctrlHresAgents','boolean','1','Contr&ocirc;le des heures des agents le samedi et le dimanche','Planning','',NULL,0),(21,'agentsIndispo','boolean','1','Afficher les agents indisponibles','Planning','',NULL,5),(22,'Granularite','enum2','30','Granularit&eacute; des champs horaires.',' Divers','[[1, \"Libre\"],[60,\"Heure\"],[30,\"Demi-heure\"],[15,\"Quart d\'heure\"],[5,\"5 minutes\"]]',NULL,30),(23,'Absences-planning','enum2','0','Choix des listes de présence et d\'absences à afficher sous les plannings','Absences','[[0,\"\"],[1,\"simple\"],[2,\"détaillé\"],[3,\"absents et présents\"],[4,\"absents et présents filtrés par site\"]]',NULL,25),(24,'Auth-Mode','enum','SQL','Méthode d\'authentification','Authentification','SQL,LDAP,LDAP-SQL,CAS,CAS-SQL,OpenIDConnect',NULL,7),(25,'Absences-apresValidation','boolean','1','Autoriser l\'enregistrement d\'absences après validation des plannings','Absences','',NULL,10),(26,'Absences-planningVide','boolean','1','Autoriser l\'enregistrement d\'absences sur des plannings en cours d\'élaboration','Absences','',NULL,8),(27,'Multisites-nombre','enum','1','Nombre de sites','Multisites','1,2,3,4,5,6,7,8,9,10',NULL,10),(28,'Multisites-site1','text','','Nom du site N°1','Multisites','',NULL,20),(29,'Multisites-site1-mail','text','','Adresses e-mails de la cellule planning du site N°1, séparées par des ;','Multisites','',NULL,25),(30,'Multisites-site2','text','','Nom du site N°2','Multisites','',NULL,30),(31,'Multisites-site2-mail','text','','Adresses e-mails de la cellule planning du site N°2, séparées par des ;','Multisites','',NULL,35),(32,'Multisites-site3','text','','Nom du site N°3','Multisites','',NULL,40),(33,'Multisites-site3-mail','text','','Adresses e-mails de la cellule planning du site N°3, séparées par des ;','Multisites','',NULL,45),(34,'Multisites-site4','text','','Nom du site N°4','Multisites','',NULL,50),(35,'Multisites-site4-mail','text','','Adresses e-mails de la cellule planning du site N°4, séparées par des ;','Multisites','',NULL,55),(36,'Multisites-site5','text','','Nom du site N°5','Multisites','',NULL,60),(37,'Multisites-site5-mail','text','','Adresses e-mails de la cellule planning du site N°5, séparées par des ;','Multisites','',NULL,65),(38,'Multisites-site6','text','','Nom du site N°6','Multisites','',NULL,70),(39,'Multisites-site6-mail','text','','Adresses e-mails de la cellule planning du site N°6, séparées par des ;','Multisites','',NULL,75),(40,'Multisites-site7','text','','Nom du site N°7','Multisites','',NULL,80),(41,'Multisites-site7-mail','text','','Adresses e-mails de la cellule planning du site N°7, séparées par des ;','Multisites','',NULL,85),(42,'Multisites-site8','text','','Nom du site N°8','Multisites','',NULL,90),(43,'Multisites-site8-mail','text','','Adresses e-mails de la cellule planning du site N°8, séparées par des ;','Multisites','',NULL,95),(44,'Multisites-site9','text','','Nom du site N°9','Multisites','',NULL,100),(45,'Multisites-site9-mail','text','','Adresses e-mails de la cellule planning du site N°9, séparées par des ;','Multisites','',NULL,105),(46,'Multisites-site10','text','','Nom du site N°10','Multisites','',NULL,110),(47,'Multisites-site10-mail','text','','Adresses e-mails de la cellule planning du site N°10, séparées par des ;','Multisites','',NULL,115),(48,'hres4semaines','boolean','0','Afficher le total d\'heures des 4 dernières semaine dans le menu','Planning','',NULL,5),(49,'Auth-Anonyme','info','0','Autoriser les logins anonymes','Authentification','',NULL,7),(50,'EDTSamedi','enum2','0','Horaires différents les semaines avec samedi travaillé et semaines à ouverture restreinte. Ce paramètre est ignoré si PlanningHebdo est activé.','Heures de présence','[[0, \"Désactivé\"], [1, \"Horaires différents les semaines avec samedi travaillé\"], [2, \"Horaires différents les semaines avec samedi travaillé et les semaines à ouverture restreinte\"]]',NULL,0),(164,'Absences-journeeEntiere','boolean','1','Le paramètre \"Journée(s) entière(s)\" est coché par défaut lors de la saisie d\'une absence.','Absences','',NULL,38),(51,'ClasseParService','boolean','0','Classer les agents par service dans le menu d&eacute;roulant du planning','Planning','',NULL,5),(52,'Alerte2SP','boolean','1','Alerter si l&apos;agent fera 2 plages de service public de suite','Planning','',NULL,5),(53,'CatAFinDeService','boolean','0','Alerter si aucun agent de cat&eacute;gorie A n&apos;est plac&eacute; en fin de service','Planning','',NULL,0),(54,'Conges-Recuperations','enum2','1','Traiter les r&eacute;cup&eacute;rations comme les cong&eacute;s (Assembler), ou les traiter s&eacute;par&eacute;ment (Dissocier)','Congés','[[0,\"Assembler\"],[1,\"Dissocier\"]]',NULL,3),(55,'Recup-Agent','enum2','0','Type de champ pour la r&eacute;cup&eacute;ration des samedis dans la fiche des agents.<br/>Rien [vide], champ <b>texte</b> ou <b>menu d&eacute;roulant</b>','Congés','[[0,\"\"],[1,\"Texte\"],[2,\"Menu déroulant\"]]',NULL,40),(56,'Recup-SamediSeulement','boolean','0','Autoriser les demandes de récupération des samedis seulement','Congés','',NULL,20),(57,'Recup-Uneparjour','boolean','1','Autoriser une seule demande de r&eacute;cup&eacute;ration par jour','Congés','',NULL,19),(58,'Recup-DeuxSamedis','boolean','0','Autoriser les demandes de récupération pour 2 samedis','Congés','',NULL,30),(59,'Recup-DelaiDefaut','text','7','Delai pour les demandes de récupération par d&eacute;faut (en jours)','Congés','',NULL,40),(60,'Recup-DelaiTitulaire1','enum2','0','Delai pour les demandes de récupération des titulaires pour 1 samedi (en mois)','Congés','[[-1,\"Défaut\"],[0,0],[1,1],[2,2],[3,3],[4,4],[5,5]]',NULL,50),(61,'Recup-DelaiTitulaire2','enum2','0','Delai pour les demandes de récupération des titulaires pour 2 samedis (en mois)','Congés','[[-1,\"Défaut\"],[0,0],[1,1],[2,2],[3,3],[4,4],[5,5]]',NULL,60),(62,'Recup-DelaiContractuel1','enum2','0','Delai pour les demandes de récupération des contractuels pour 1 samedi (en semaines)','Congés','[[-1,\"Défaut\"],[0,0],[1,1],[2,2],[3,3],[4,4],[5,5]]',NULL,70),(63,'Recup-DelaiContractuel2','enum2','0','Delai pour les demandes de récupération des contractuels pour 2 samedis (en semaines)','Congés','[[-1,\"Défaut\"],[0,0],[1,1],[2,2],[3,3],[4,4],[5,5]]',NULL,80),(64,'Recup-notifications1','checkboxes','[\"2\"]','Destinataires des notifications de nouvelles demandes de crédit de récupérations','Congés','[[0,\"Agents ayant le droit de gérer les récupérations\"],[1,\"Responsables directs\"],[2,\"Cellule planning\"],[3,\"Agent concerné\"]]',NULL,100),(65,'Recup-notifications2','checkboxes','[\"2\"]','Destinataires des notifications de modification de crédit de récupérations','Congés','[[0,\"Agents ayant le droit de gérer les récupérations\"],[1,\"Responsables directs\"],[2,\"Cellule planning\"],[3,\"Agent concerné\"]]',NULL,100),(66,'Recup-notifications3','checkboxes','[\"1\"]','Destinataires des notifications des validations de crédit de récupérations niveau 1','Congés','[[0,\"Agents ayant le droit de gérer les récupérations\"],[1,\"Responsables directs\"],[2,\"Cellule planning\"],[3,\"Agent concerné\"]]',NULL,100),(67,'Recup-notifications4','checkboxes','[\"3\"]','Destinataires des notifications des validations de crédit de récupérations niveau 2','Congés','[[0,\"Agents ayant le droit de gérer les récupérations\"],[1,\"Responsables directs\"],[2,\"Cellule planning\"],[3,\"Agent concerné\"]]',NULL,100),(68,'Conges-Rappels','boolean','0','Activer / D&eacute;sactiver l&apos;envoi de rappels s&apos;il y a des cong&eacute;s non-valid&eacute;s','Congés','',NULL,7),(69,'Conges-Rappels-Jours','text','14','Nombre de jours &agrave; contr&ocirc;ler pour l&apos;envoi de rappels sur les cong&eacute;s non-valid&eacute;s','Congés','',NULL,8),(70,'Conges-Rappels-N1','checkboxes','[\"Mail-Planning\"]','A qui envoyer les rappels sur les cong&eacute;s non-valid&eacute;s au niveau 1','Congés','[[\"Mail-Planning\",\"La cellule planning\"],[\"mails_responsables\",\"Les responsables hi&eacute;rarchiques\"]]',NULL,13),(71,'Conges-Rappels-N2','checkboxes','[\"mails_responsables\"]','A qui envoyer les rappels sur les cong&eacute;s non-valid&eacute;s au niveau 2','Congés','[[\"Mail-Planning\",\"La cellule planning\"],[\"mails_responsables\",\"Les responsables hi&eacute;rarchiques\"]]',NULL,15),(72,'Conges-Validation-N2','enum2','0','La validation niveau 2 des cong&eacute;s peut se faire directement ou doit attendre la validation niveau 1','Congés','[[0,\"Validation directe autoris&eacute;e\"],[1,\"Le cong&eacute; doit &ecirc;tre valid&eacute; au niveau 1\"]]',NULL,5),(73,'Conges-Enable','boolean','0','Activer le module Congés','Congés','',NULL,1),(74,'Absences-validation','boolean','0','Les absences doivent &ecirc;tre valid&eacute;es par un administrateur avant d&apos;&ecirc;tre prises en compte','Absences','',NULL,30),(75,'Absences-non-validees','boolean','1','Dans les plannings, afficher en rouge les agents pour lesquels une absence non-valid&eacute;e est enregistr&eacute;e','Absences','',NULL,35),(76,'Absences-agent-preselection','boolean','1','Présélectionner l&apos;agent connecté lors de l&apos;ajout d&apos;une nouvelle absence.','Absences','',NULL,36),(77,'Absences-tous','boolean','0','Autoriser l&apos;enregistrement d&apos;absences pour tous les agents en une fois','Absences','',NULL,37),(78,'Absences-adminSeulement','boolean','0','Autoriser la saisie des absences aux administrateurs seulement.','Absences','',NULL,20),(79,'Mail-Planning','textarea','','Adresses e-mails de la cellule planning, s&eacute;par&eacute;es par des ;','Messagerie','',NULL,10),(80,'Planning-sansRepas','boolean','1','Afficher une notification pour les Sans Repas dans le menu d&eacute;roulant et dans le planning','Planning','',NULL,10),(81,'Planning-dejaPlace','boolean','1','Afficher une notification pour les agents d&eacute;j&agrave; plac&eacute; sur un poste dans le menu d&eacute;roulant du planning','Planning','',NULL,20),(82,'Planning-Heures','boolean','1','Afficher les heures &agrave; c&ocirc;t&eacute; du nom des agents dans le menu du planning','Planning','',NULL,25),(83,'Planning-CommentairesToujoursActifs','boolean','0','Afficher la zone de commentaire m&ecirc;me si le planning n\'est pas encore commenc&eacute;.','Planning','',NULL,100),(84,'Absences-notifications-A1','checkboxes','[\"2\"]','Destinataires des notifications de nouvelles absences (Circuit A)','Absences','[[0,\"Agents ayant le droit de g&eacute;rer les absences\"],[1,\"Responsables directs\"],[2,\"Cellule planning\"],[3,\"Agent concern&eacute;\"]]',NULL,40),(85,'Absences-notifications-A2','checkboxes','[\"2\"]','Destinataires des notifications de modification d&apos;absences (Circuit A)','Absences','[[0,\"Agents ayant le droit de g&eacute;rer les absences\"],[1,\"Responsables directs\"],[2,\"Cellule planning\"],[3,\"Agent concern&eacute;\"]]',NULL,50),(86,'Absences-notifications-A3','checkboxes','[\"1\"]','Destinataires des notifications des validations niveau 1 (Circuit A)','Absences','[[0,\"Agents ayant le droit de g&eacute;rer les absences\"],[1,\"Responsables directs\"],[2,\"Cellule planning\"],[3,\"Agent concern&eacute;\"]]',NULL,60),(87,'Absences-notifications-A4','checkboxes','[\"3\"]','Destinataires des notifications des validations niveau 2 (Circuit A)','Absences','[[0,\"Agents ayant le droit de g&eacute;rer les absences\"],[1,\"Responsables directs\"],[2,\"Cellule planning\"],[3,\"Agent concern&eacute;\"]]',NULL,70),(88,'Absences-notifications-agent-par-agent','boolean','0','Gestion des notifications et des droits de validations agent par agent. Si cette option est activée, les paramètres Absences-notifications-A1, A2, A3 et A4 ou B1, B2, B3 et B4 seront écrasés par les choix fait dans la page de configuration des notifications du menu Administration - Notifications / Validations','Absences','',NULL,120),(89,'Absences-notifications-titre','text','','Titre personnalis&eacute; pour les notifications de nouvelles absences','Absences','',NULL,130),(90,'Absences-notifications-message','textarea','','Message personnalis&eacute; pour les notifications de nouvelles absences','Absences','',NULL,140),(91,'Statistiques-Heures','textarea','','Afficher des statistiques sur les cr&eacute;neaux horaires voulus. Les cr&eacute;neaux doivent &ecirc;tre au format 00h00-00h00 et s&eacute;par&eacute;s par des ; Exemple : 19h00-20h00; 20h00-21h00; 21h00-22h00','Statistiques','',NULL,10),(92,'Affichage-theme','text','default','Th&egrave;me de l&apos;application.','Affichage','',NULL,10),(93,'Affichage-titre','text','','Titre affich&eacute; sur la page d&apos;accueil','Affichage','',NULL,20),(94,'Affichage-etages','boolean','0','Afficher les &eacute;tages des postes dans le planning','Affichage','',NULL,30),(95,'Planning-NbAgentsCellule','enum','4','Nombre d&apos;agents maximum par cellule','Planning','1,2,3,4,5,6,7,8,10,11,12,13,14,15,16,17,18,19,20',NULL,2),(96,'Planning-lignesVides','boolean','1','Afficher ou non les lignes vides dans les plannings valid&eacute;s','Planning','',NULL,3),(97,'Planning-SR-debut','enum2','12:00:00','Heure de d&eacute;but pour la v&eacute;rification des sans repas','Planning','[[\"11:00:00\",\"11h00\"],[\"11:15:00\",\"11h15\"],[\"11:30:00\",\"11h30\"],[\"11:45:00\",\"11h45\"],[\"12:00:00\",\"12h00\"],[\"12:15:00\",\"12h15\"],[\"12:30:00\",\"12h30\"],[\"12:45:00\",\"12h45\"],[\"13:00:00\",\"13h00\"],[\"13:15:00\",\"13h15\"],[\"13:30:00\",\"13h30\"],[\"13:45:00\",\"13h45\"],[\"14:00:00\",\"14h00\"],[\"14:15:00\",\"14h15\"],[\"14:30:00\",\"14h30\"],[\"14:45:00\",\"14h45\"]]',NULL,11),(98,'Planning-SR-fin','enum2','14:00:00','Heure de fin pour la v&eacute;rification des sans repas','Planning','[[\"11:15:00\",\"11h15\"],[\"11:30:00\",\"11h30\"],[\"11:45:00\",\"11h45\"],[\"12:00:00\",\"12h00\"],[\"12:15:00\",\"12h15\"],[\"12:30:00\",\"12h30\"],[\"12:45:00\",\"12h45\"],[\"13:00:00\",\"13h00\"],[\"13:15:00\",\"13h15\"],[\"13:30:00\",\"13h30\"],[\"13:45:00\",\"13h45\"],[\"14:00:00\",\"14h00\"],[\"14:15:00\",\"14h15\"],[\"14:30:00\",\"14h30\"],[\"14:45:00\",\"14h45\"],[\"15:00:00\",\"15h00\"]]',NULL,12),(99,'Planning-Absences-Heures-Hebdo','boolean','0','Prendre en compte les absences pour calculer le nombre d&apos;heures de SP &agrave; effectuer. (Module PlanningHebdo requis)','Planning','',NULL,30),(100,'CAS-Debug','boolean','0','Activer le débogage pour CAS. Créé un fichier \"cas_debug.txt\" dans le dossier \"[TEMP]\"','CAS','',NULL,50),(101,'PlanningHebdo','boolean','1','Utiliser le module “Planning Hebdo”. Ce module permet d\'enregistrer plusieurs horaires de présence par agent en définissant des périodes d\'utilisation. (Incompatible avec l\'option EDTSamedi)','Heures de présence','',NULL,40),(102,'PlanningHebdo-Agents','boolean','0','Autoriser les agents à saisir leurs heures de présence (avec le module Planning Hebdo). Les heures saisies devront être validées par un administrateur','Heures de présence','',NULL,50),(103,'PlanningHebdo-Pause2','boolean','0','2 pauses dans une journ&eacute;e','Heures de présence','',NULL,60),(104,'PlanningHebdo-notifications1','checkboxes','[\"3\"]','Destinataires des notifications d\'enregistrement de nouvelles heures de présence','Heures de présence','[[0,\"Agents ayant le droit de valider les heures de pr&eacute;sence au niveau 1\"],[1,\"Agents ayant le droit de valider les heures de pr&eacute;sence au niveau 2\"],[2,\"Responsables directs\"],[3,\"Cellule planning\"],[4,\"Agent concern&eacute;\"]]',NULL,70),(105,'PlanningHebdo-notifications2','checkboxes','[\"3\"]','Destinataires des notifications de modification des heures de présence','Heures de présence','[[0,\"Agents ayant le droit de valider les heures de pr&eacute;sence au niveau 1\"],[1,\"Agents ayant le droit de valider les heures de pr&eacute;sence au niveau 2\"],[2,\"Responsables directs\"],[3,\"Cellule planning\"],[4,\"Agent concern&eacute;\"]]',NULL,72),(106,'PlanningHebdo-notifications3','checkboxes','[\"2\"]','Destinataires des notifications des validations niveau 1','Heures de présence','[[0,\"Agents ayant le droit de valider les heures de pr&eacute;sence au niveau 1\"],[1,\"Agents ayant le droit de valider les heures de pr&eacute;sence au niveau 2\"],[2,\"Responsables directs\"],[3,\"Cellule planning\"],[4,\"Agent concern&eacute;\"]]',NULL,74),(107,'PlanningHebdo-notifications4','checkboxes','[\"4\"]','Destinataires des notifications des validations niveau 2','Heures de présence','[[0,\"Agents ayant le droit de valider les heures de pr&eacute;sence au niveau 1\"],[1,\"Agents ayant le droit de valider les heures de pr&eacute;sence au niveau 2\"],[2,\"Responsables directs\"],[3,\"Cellule planning\"],[4,\"Agent concern&eacute;\"]]',NULL,76),(108,'PlanningHebdo-notifications-agent-par-agent','boolean','0','Gestion des notifications et des droits de validations agent par agent. Si cette option est activée, les paramètres PlanningHebdo-notifications1, 2, 3 et 4 seront écrasés par les choix fait dans la page de configuration des notifications du menu Administration - Notifications / Validations','Heures de présence','',NULL,80),(109,'PlanningHebdo-Validation-N2','enum2','0','La validation niveau 2 des heures de présence peut se faire directement ou doit attendre la validation niveau 1','Heures de présence','[[0,\"Validation directe autoris&eacute;e\"],[1,\"Le planning doit &ecirc;tre valid&eacute; au niveau 1\"]]',NULL,85),(110,'Planning-Notifications','boolean','0','Envoyer une notification aux agents lors de la validation des plannings les concernant','Planning','',NULL,40),(111,'Planning-TableauxMasques','boolean','1','Autoriser le masquage de certains tableaux du planning','Planning','',NULL,50),(112,'Planning-AppelDispo','boolean','0','Permettre l&apos;envoi d&apos;un mail aux agents disponibles pour leur demander s&apos;ils sont volontaires pour occuper le poste choisi.','Planning','',NULL,60),(113,'Planning-AppelDispoSujet','text','Appel à disponibilité [poste] [date] [debut]-[fin]','Sujet du mail pour les appels &agrave; disponibilit&eacute;','Planning','',NULL,70),(114,'Planning-AppelDispoMessage','textarea','Chers tous,\r\n\r\nLe poste [poste] est vacant le [date] de [debut] à [fin].\r\n\r\nSi vous souhaitez occuper ce poste, vous pouvez répondre à cet e-mail.\r\n\r\nCordialement,\r\nLa cellule planning','Corps du mail pour les appels &agrave; disponibilit&eacute;','Planning','',NULL,80),(115,'LDAP-Host','','','Nom d&apos;h&ocirc;te ou adresse IP du serveur LDAP','LDAP','',NULL,10),(116,'LDAP-Port','','','Port du serveur LDAP','LDAP','',NULL,20),(117,'LDAP-Protocol','enum','ldap','Protocol utilis&eacute;','LDAP','ldap,ldaps',NULL,30),(118,'LDAP-Suffix','','','Base LDAP','LDAP','',NULL,40),(119,'LDAP-Filter','','','Filtre LDAP. OpenLDAP essayez \"(objectclass=inetorgperson)\" , Active Directory essayez \"(&(objectCategory=person)(objectClass=user))\". Vous pouvez bien-s&ucirc;r personnaliser votre filtre.','LDAP','',NULL,50),(120,'LDAP-RDN','','','DN de connexion au serveur LDAP, laissez vide si connexion anonyme','LDAP','',NULL,60),(121,'LDAP-Password','password','::7839a596eb1f3aa523db75816c55f1a3','Mot de passe de connexion','LDAP','',NULL,70),(122,'LDAP-ID-Attribute','enum','uid','Attribut d&apos;authentification (OpenLDAP : uid, Active Directory : samaccountname)','LDAP','uid,samaccountname,supannaliaslogin',NULL,80),(123,'LDAP-Matricule','text','','Attribut &agrave; importer dans le champ matricule (optionnel)','LDAP','',NULL,90),(124,'CAS-Hostname','','','Nom d&apos;h&ocirc;te du serveur CAS','CAS','',NULL,30),(125,'CAS-Port','','8080','Port serveur CAS','CAS','',NULL,30),(126,'CAS-Version','enum','2.0','Version du serveur CAS','CAS','2.0,3.0,4.0',NULL,30),(127,'CAS-CACert','','','Chemin absolut du certificat de l&apos;Autorit&eacute; de Certification. Si pas renseign&eacute;, l&apos;identit&eacute; du serveur ne sera pas v&eacute;rifi&eacute;e.','CAS','',NULL,30),(128,'CAS-SSLVersion','enum2','1','Version SSL/TLS &agrave; utiliser pour les &eacute;changes avec le serveur CAS','CAS','[[1,\"TLSv1\"],[4,\"TLSv1_0\"],[5,\"TLSv1_1\"],[6,\"TLSv1_2\"]]',NULL,45),(129,'CAS-ServiceURL','text','','URL de Planno. A renseigner seulement si la redirection ne fonctionne pas après authentification sur le serveur CAS, si vous utilisez un Reverse Proxy par exemple.','CAS','',NULL,47),(130,'CAS-URI','','cas','Page de connexion CAS','CAS','',NULL,30),(131,'CAS-URI-Logout','','cas/logout','Page de d&eacute;connexion CAS','CAS','',NULL,30),(132,'Rappels-Actifs','boolean','0','Activer les rappels','Rappels','',NULL,10),(133,'Rappels-Jours','enum2','3','Nombre de jours &agrave; contr&ocirc;ler pour les rappels','Rappels','[[1,1],[2,2],[3,3],[4,4],[5,5],[6,6],[7,7]]',NULL,20),(134,'Rappels-Renfort','boolean','0','Contr&ocirc;ler les postes de renfort lors des rappels','Rappels','',NULL,30),(135,'IPBlocker-TimeChecked','text','10','Recherche les &eacute;checs d&apos;authentification lors des N derni&egrave;res minutes. ( 0 = IPBlocker d&eacute;sactiv&eacute; )','Authentification','',NULL,40),(136,'IPBlocker-Attempts','text','5','Nombre d&apos;&eacute;checs d&apos;authentification autoris&eacute;s lors des N derni&egrave;res minutes','Authentification','',NULL,50),(137,'IPBlocker-Wait','text','10','Temps de blocage de l&apos;IP en minutes','Authentification','',NULL,60),(138,'ICS-Server1','text','','URL du 1<sup>er</sup> serveur ICS avec la variable OpenURL entre crochets. Ex: http://server.domain.com/calendars/[email].ics','ICS','',NULL,10),(139,'ICS-Pattern1','text','','Motif d&apos;absence pour les &eacute;v&eacute;nements import&eacute;s du 1<sup>er</sup> serveur. Ex: Agenda Personnel','ICS','',NULL,20),(140,'ICS-Status1','enum2','CONFIRMED','Importer tous les &eacute;v&eacute;nements ou seulement les &eacute;v&eacute;nements confirm&eacute;s (attribut STATUS = CONFIRMED). Si \"tous\" est choisi, les &eacute;v&eacute;nements non-confirm&eacute;s seront enregistr&eacute;s comme des absences en attente de validation','ICS','[[\"CONFIRMED\",\"Confirm&eacute;s\"],[\"ALL\",\"Tous\"]]',NULL,22),(141,'ICS-Server2','text','','URL du 2<sup>&egrave;me</sup> serveur ICS avec la variable OpenURL entre crochets. Ex: http://server2.domain.com/holiday/[login].ics','ICS','',NULL,30),(142,'ICS-Pattern2','text','','Motif d&apos;absence pour les &eacute;v&eacute;nements import&eacute;s du 2<sup>&egrave;me</sup> serveur. Ex: Congés','ICS','',NULL,40),(143,'ICS-Status2','enum2','CONFIRMED','Importer tous les &eacute;v&eacute;nements ou seulement les &eacute;v&eacute;nements confirm&eacute;s (attribut STATUS = CONFIRMED). Si \"tous\" est choisi, les &eacute;v&eacute;nements non-confirm&eacute;s seront enregistr&eacute;s comme des absences en attente de validation','ICS','[[\"CONFIRMED\",\"Confirm&eacute;s\"],[\"ALL\",\"Tous\"]]',NULL,42),(144,'ICS-Server3','boolean','0','Utiliser une URL d&eacute;finie pour chaque agent dans le menu Administration / Les agents','ICS','',NULL,44),(145,'ICS-Pattern3','text','','Motif d&apos;absence pour les &eacute;v&eacute;nements import&eacute;s depuis l&apos;URL d&eacute;finie dans la fiche des agents. Ex: Agenda personnel','ICS','',NULL,45),(146,'ICS-Status3','enum2','CONFIRMED','Importer tous les &eacute;v&eacute;nements ou seulement les &eacute;v&eacute;nements confirm&eacute;s (attribut STATUS = CONFIRMED). Si \"tous\" est choisi, les &eacute;v&eacute;nements non-confirm&eacute;s seront enregistr&eacute;s comme des absences en attente de validation','ICS','[[\"CONFIRMED\",\"Confirm&eacute;s\"],[\"ALL\",\"Tous\"]]',NULL,47),(147,'ICS-Export','boolean','0','Autoriser l&apos;exportation des plages de service public sous forme de calendriers ICS. Un calendrier par agent, accessible &agrave; l&apos;adresse [SERVER]/ics/calendar.php?login=[login_de_l_agent]','ICS','',NULL,60),(148,'ICS-Code','boolean','1','Prot&eacute;ger les calendriers ICS par des codes de façon &agrave; ce qu&apos;on ne puisse pas deviner les URLs. Si l&apos;option est activ&eacute;e, les URL seront du type : [SERVER]/ics/calendar.php?login=[login_de_l_agent]&amp;code=[code_al&eacute;atoire]','ICS','',NULL,70),(149,'PlanningHebdo-CSV','text','','Emplacement du fichier CSV &agrave; importer (importation automatis&eacute;e) Ex: /dossier/fichier.csv','Heures de présence','',NULL,90),(150,'Agenda-Plannings-Non-Valides','boolean','0','Afficher ou non les plages de service public des plannings non valid&eacute;s dans les agendas.','Agenda','',NULL,10),(151,'Planning-agents-volants','boolean','0','Utiliser le module \"Agents volants\" permettant de diff&eacute;rencier un groupe d&apos;agents dans le planning','Planning','',NULL,90),(152,'Hamac-csv','text','','Chemin d&apos;acc&egrave;s au fichier CSV pour l&apos;importation des absences depuis Hamac','Hamac','',NULL,10),(153,'Hamac-motif','text','','Motif pour les absences import&eacute;s depuis Hamac. Ex: Hamac','Hamac','',NULL,20),(154,'Hamac-status','enum2','1,2,3,5,6','Importer les absences valid&eacute;es et en attente de validation ou seulement les absences valid&eacute;es.','Hamac','[[\"1,2,3,5,6\",\"Valid&eacute;es et en attente de validation\"],[\"2\",\"Valid&eacute;es\"]]',NULL,30),(155,'Hamac-id','enum2','login','Champ Planno à utiliser pour mapper les agents.','Hamac','[[\"login\",\"Login\"],[\"matricule\",\"Matricule\"]]',NULL,40),(156,'Conges-Mode','enum2','jours','Décompte des congés en heures ou en jours','Congés','[[\"heures\",\"Heures\"],[\"jours\",\"Jours\"]]',NULL,2),(157,'Absences-notifications-B1','checkboxes','[\"2\"]','Destinataires des notifications de nouvelles absences (Circuit B)','Absences','[[0,\"Agents ayant le droit de g&eacute;rer les absences\"],[1,\"Responsables directs\"],[2,\"Cellule planning\"],[3,\"Agent concern&eacute;\"]]',NULL,80),(158,'Absences-notifications-B2','checkboxes','[\"2\"]','Destinataires des notifications de modification d&apos;absences (Circuit B)','Absences','[[0,\"Agents ayant le droit de g&eacute;rer les absences\"],[1,\"Responsables directs\"],[2,\"Cellule planning\"],[3,\"Agent concern&eacute;\"]]',NULL,90),(159,'Absences-notifications-B3','checkboxes','[\"1\"]','Destinataires des notifications des validations niveau 1 (Circuit B)','Absences','[[0,\"Agents ayant le droit de g&eacute;rer les absences\"],[1,\"Responsables directs\"],[2,\"Cellule planning\"],[3,\"Agent concern&eacute;\"]]',NULL,100),(160,'Absences-notifications-B4','checkboxes','[\"3\"]','Destinataires des notifications des validations niveau 2 (Circuit B)','Absences','[[0,\"Agents ayant le droit de g&eacute;rer les absences\"],[1,\"Responsables directs\"],[2,\"Cellule planning\"],[3,\"Agent concern&eacute;\"]]',NULL,110),(161,'Absences-DelaiSuppressionDocuments','text','365','Les documents associ&eacute;s aux absences sont supprim&eacute;s au-del&agrave; du nombre de jours d&eacute;finis par ce param&egrave;tre.','Absences','',NULL,150),(162,'Conges-demi-journees','boolean','0','Autorise la saisie de congés en demi-journée. Fonctionne uniquement avec le mode de saisie en jour','Congés','',NULL,8),(163,'PlanningHebdo-PauseLibre','boolean','1','Ajoute la possibilité de saisir un temps de pause libre dans les heures de présence (Module Planning Hebdo uniquement)','Heures de présence','',NULL,65),(165,'Journey-time-between-sites','text','0','Temps de trajet moyen entre sites (en minutes)','Planning','',NULL,95),(166,'Journey-time-between-areas','text','0','Temps de trajet moyen entre zones (en minutes)','Planning','',NULL,96),(167,'Journey-time-for-absences','text','0','Temps de trajet moyen entre une absence et un poste de service public (en minutes)','Planning','',NULL,97),(168,'Conges-fullday-switching-time','text','4','Temps définissant la bascule entre une demi-journée et une journée complète lorsque les crédits de congés sont comptés en jours. Format : entier ou décimal. Exemple : pour 3h30, tapez 3.5','Congés','',NULL,9),(169,'Conges-planningVide','boolean','1','Autoriser l\'enregistrement de congés sur des plannings en cours d\'élaboration','Congés','',NULL,11),(170,'Conges-apresValidation','boolean','1','Autoriser l\'enregistrement de congés après validation des plannings','Congés','',NULL,12),(171,'Conges-validation','boolean','1','Les congés doivent être validés par un administrateur avant d\'être pris en compte','Congés','',NULL,4),(172,'Hamac-debug','boolean','0','Active le mode débugage pour l\'importation des absences depuis Hamac. Les informations de débugage sont écrites dans la table \"log\". Attention, si cette option est activée, la taille de la base de données augmente considérablement.','Hamac','',NULL,50),(183,'Conges-tous','boolean','0','Autoriser l\'enregistrement de congés pour tous les agents en une fois','Congés','',NULL,6),(184,'Conges-fullday-reference-time','text','','Temps de référence (en heures) pour une journée complète. Si ce champ est renseigné et que les crédits de congés sont gérés en jours, la différence de temps de chaque journée sera créditée ou débitée du solde des récupérations. Format : entier ou décimal. Exemple : pour 7h30, tapez 7.5','Congés','',NULL,10),(186,'PlanningHebdo-DebutPauseLibre','enum2','12:00:00','Début de période de pause libre','Heures de présence','[[\"11:00:00\",\"11h00\"],[\"11:15:00\",\"11h15\"],[\"11:30:00\",\"11h30\"],[\"11:45:00\",\"11h45\"],[\"12:00:00\",\"12h00\"],[\"12:15:00\",\"12h15\"],[\"12:30:00\",\"12h30\"],[\"12:45:00\",\"12h45\"],[\"13:00:00\",\"13h00\"],[\"13:15:00\",\"13h15\"],[\"13:30:00\",\"13h30\"],[\"13:45:00\",\"13h45\"],[\"14:00:00\",\"14h00\"],[\"14:15:00\",\"14h15\"],[\"14:30:00\",\"14h30\"],[\"14:45:00\",\"14h45\"]]',NULL,66),(187,'PlanningHebdo-FinPauseLibre','enum2','14:00:00','Fin de période de pause libre','Heures de présence','[[\"11:15:00\",\"11h15\"],[\"11:30:00\",\"11h30\"],[\"11:45:00\",\"11h45\"],[\"12:00:00\",\"12h00\"],[\"12:15:00\",\"12h15\"],[\"12:30:00\",\"12h30\"],[\"12:45:00\",\"12h45\"],[\"13:00:00\",\"13h00\"],[\"13:15:00\",\"13h15\"],[\"13:30:00\",\"13h30\"],[\"13:45:00\",\"13h45\"],[\"14:00:00\",\"14h00\"],[\"14:15:00\",\"14h15\"],[\"14:30:00\",\"14h30\"],[\"14:45:00\",\"14h45\"],[\"15:00:00\",\"15h00\"]]',NULL,67),(188,'Planook','hidden','0','Version Lite Planook',' Divers','',NULL,0),(189,'Auth-PasswordLength','text','8','Nombre minimum de caractères obligatoires pour le changement de mot de passe.','Authentification','',NULL,20),(190,'legalNotices','textarea','','Mentions légales (exemple : notice RGPD). La syntaxe markdown peut être utilisée pour la saisie.','Mentions légales','',NULL,10),(191,'Absences-Validation-N2','enum2','0','La validation niveau 2 des absences peut se faire directement ou doit attendre la validation niveau 1','Absences','[[0,\"Validation directe autoris&eacute;e\"],[1,\"L\'absence doit &ecirc;tre valid&eacute; au niveau 1\"]]',NULL,31),(192,'Conges-transfer-comp-time','boolean','0','Transférer les récupérations restantes sur le reliquat','Congés','',NULL,16),(193,'CAS-LoginAttribute','text','','Attribut CAS à utiliser pour mapper l\'utilisateur si et seulement si l\'UID CAS ne convient pas. Laisser ce champ vide par défaut. Exemple : \"mail\", dans ce cas, l\'adresse mail de l\'utilisateur est fournie par le serveur CAS et elle est renseignée dans le champ \"login\" des fiches agents de Planno.','CAS','',NULL,48),(194,'ICS-Interval','text','365','Restriction de la période à exporter : renseigner le nombre de jours à rechercher dans le passé. Les événements à venir sont toujours exportés. Si le champ n\'est pas renseigné, tous les événements seront recherchés.','ICS','',NULL,80),(195,'Affichage-Agent','color','#fff3b3','Couleur des cellules de l\'agent connecté','Affichage','',NULL,40),(196,'Absences-blocage','boolean','0','Permettre le blocage des absences et congés sur une période définie par les gestionnaires. Ce paramètre empêchera les agents qui n\'ont pas le droits de gérer les absences d\'enregistrer absences et congés sur les périodes définies. En configuration multi-sites, les agents de tous les sites seront bloqués sans distinction.','Absences','',NULL,5),(197,'LDIF-File','text','','Emplacement d\'un fichier LDIF pour l\'importation des agents','LDIF','',NULL,10),(198,'LDIF-ID-Attribute','enum','uid','Attribut d\'authentification (OpenLDAP : uid, Active Directory : samaccountname)','LDIF','uid,samaccountname,supannaliaslogin',NULL,20),(199,'LDIF-Matricule','text','','Attribut à importer dans le champ matricule (optionnel)','LDIF','',NULL,30),(200,'MT42875_dateDebutPlHebdo','hidden','nb_semaine: 1 (<5): nothing to do\n','','Heures de présence','',NULL,0),(201,'ICS-Description1','boolean','1','Inclure la description de l\'événement importé dans le commentaire de l\'absence','ICS','',NULL,23),(202,'ICS-Description2','boolean','1','Inclure la description de l\'événement importé dans le commentaire de l\'absence','ICS','',NULL,43),(203,'ICS-Description3','boolean','1','Inclure la description de l\'événement importé dans le commentaire de l\'absence','ICS','',NULL,48),(204,'Contract_users','hidden','20','utilisateurs autorisés par le contrat','Contract','','NULL',10);
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conges`
--

DROP TABLE IF EXISTS `conges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `perso_id` int(11) NOT NULL,
  `debut` datetime NOT NULL,
  `fin` datetime NOT NULL,
  `halfday` tinyint(4) DEFAULT 0,
  `start_halfday` varchar(20) DEFAULT '',
  `end_halfday` varchar(20) DEFAULT '',
  `commentaires` text DEFAULT NULL,
  `refus` text DEFAULT NULL,
  `heures` varchar(20) DEFAULT NULL,
  `debit` varchar(20) DEFAULT NULL,
  `saisie` timestamp NOT NULL DEFAULT current_timestamp(),
  `saisie_par` int(11) NOT NULL,
  `modif` int(11) NOT NULL DEFAULT 0,
  `modification` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `valide_n1` int(11) NOT NULL DEFAULT 0,
  `validation_n1` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `valide` int(11) NOT NULL DEFAULT 0,
  `validation` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `solde_prec` float DEFAULT NULL,
  `solde_actuel` float DEFAULT NULL,
  `recup_prec` float DEFAULT NULL,
  `recup_actuel` float DEFAULT NULL,
  `reliquat_prec` float DEFAULT NULL,
  `reliquat_actuel` float DEFAULT NULL,
  `anticipation_prec` float DEFAULT NULL,
  `anticipation_actuel` float DEFAULT NULL,
  `supprime` int(11) NOT NULL DEFAULT 0,
  `suppr_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `information` int(11) NOT NULL DEFAULT 0,
  `info_date` timestamp NULL DEFAULT NULL,
  `regul_id` int(11) DEFAULT NULL,
  `origin_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conges`
--

LOCK TABLES `conges` WRITE;
/*!40000 ALTER TABLE `conges` DISABLE KEYS */;
INSERT INTO `conges` VALUES (1,1,'2020-04-16 00:00:00','2020-04-16 00:00:00',0,'','',NULL,NULL,NULL,NULL,'2020-04-16 10:00:29',0,0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',0,0,0,0,0,0,0,0,0,'0000-00-00 00:00:00',999999999,'2020-04-16 10:00:29',NULL,NULL),(2,1,'2022-04-28 00:00:00','2022-04-28 00:00:00',0,'','',NULL,NULL,NULL,NULL,'2022-04-28 09:26:07',0,0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',0,0,0,0,0,0,0,0,0,'0000-00-00 00:00:00',999999999,'2022-04-28 09:26:07',NULL,NULL),(3,1,'2024-02-19 00:00:00','2024-02-19 00:00:00',0,'','',NULL,NULL,NULL,NULL,'2024-02-19 12:44:33',0,0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',0,0,0,0,0,0,0,0,0,'0000-00-00 00:00:00',999999999,'2024-02-19 12:44:33',NULL,NULL),(4,1,'2024-02-19 00:00:00','2024-02-19 00:00:00',0,'','',NULL,NULL,NULL,NULL,'2024-02-19 12:44:33',0,0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',0,0,0,0,0,0,0,0,0,'0000-00-00 00:00:00',999999999,'2024-02-19 12:44:33',NULL,NULL);
/*!40000 ALTER TABLE `conges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conges_infos`
--

DROP TABLE IF EXISTS `conges_infos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conges_infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `debut` date DEFAULT NULL,
  `fin` date DEFAULT NULL,
  `texte` text DEFAULT NULL,
  `saisie` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conges_infos`
--

LOCK TABLES `conges_infos` WRITE;
/*!40000 ALTER TABLE `conges_infos` DISABLE KEYS */;
/*!40000 ALTER TABLE `conges_infos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cron`
--

DROP TABLE IF EXISTS `cron`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cron` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `m` varchar(2) DEFAULT NULL,
  `h` varchar(2) DEFAULT NULL,
  `dom` varchar(2) DEFAULT NULL,
  `mon` varchar(2) DEFAULT NULL,
  `dow` varchar(2) DEFAULT NULL,
  `command` varchar(200) DEFAULT NULL,
  `comments` varchar(500) DEFAULT NULL,
  `last` datetime DEFAULT '0000-00-00 00:00:00',
  `disabled` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cron`
--

LOCK TABLES `cron` WRITE;
/*!40000 ALTER TABLE `cron` DISABLE KEYS */;
INSERT INTO `cron` VALUES (1,'0','0','*','*','*','cron.planning_hebdo_daily.php','Daily Cron for Planning Hebdo module','2024-04-19 16:54:07',0),(2,'0','0','1','1','*','cron.holiday_reset_remainder.php','Reset holiday remainders','2024-02-19 13:44:33',0),(3,'0','0','1','9','*','cron.holiday_reset_credits.php','Reset holiday credits','2024-02-19 13:44:33',0),(4,'0','0','1','9','*','cron.holiday_reset_comp_time.php','Reset holiday compensatory time','2024-02-19 13:44:33',0),(5,'0','0','1','9','*','cron.holiday_reset_comp_time.php','Reset holiday compensatory time','2024-02-19 13:44:33',0);
/*!40000 ALTER TABLE `cron` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edt_samedi`
--

DROP TABLE IF EXISTS `edt_samedi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edt_samedi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `perso_id` int(11) NOT NULL,
  `semaine` date DEFAULT NULL,
  `tableau` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edt_samedi`
--

LOCK TABLES `edt_samedi` WRITE;
/*!40000 ALTER TABLE `edt_samedi` DISABLE KEYS */;
/*!40000 ALTER TABLE `edt_samedi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `heures_absences`
--

DROP TABLE IF EXISTS `heures_absences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `heures_absences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `semaine` date DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `heures` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `heures_absences`
--

LOCK TABLES `heures_absences` WRITE;
/*!40000 ALTER TABLE `heures_absences` DISABLE KEYS */;
INSERT INTO `heures_absences` VALUES (1,'2024-02-19',1708595154,'[]');
/*!40000 ALTER TABLE `heures_absences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `heures_sp`
--

DROP TABLE IF EXISTS `heures_sp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `heures_sp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `semaine` date DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `heures` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `heures_sp`
--

LOCK TABLES `heures_sp` WRITE;
/*!40000 ALTER TABLE `heures_sp` DISABLE KEYS */;
INSERT INTO `heures_sp` VALUES (1,'2024-02-19',1708595154,'{\"3\":\"20\",\"8\":\"20\",\"7\":\"20\",\"4\":\"20\",\"5\":\"10\",\"6\":\"12\",\"2\":0}');
/*!40000 ALTER TABLE `heures_sp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hidden_tables`
--

DROP TABLE IF EXISTS `hidden_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hidden_tables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `perso_id` int(11) NOT NULL DEFAULT 0,
  `tableau` int(11) NOT NULL DEFAULT 0,
  `hidden_tables` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hidden_tables`
--

LOCK TABLES `hidden_tables` WRITE;
/*!40000 ALTER TABLE `hidden_tables` DISABLE KEYS */;
/*!40000 ALTER TABLE `hidden_tables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `infos`
--

DROP TABLE IF EXISTS `infos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `debut` date DEFAULT NULL,
  `fin` date DEFAULT NULL,
  `texte` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `infos`
--

LOCK TABLES `infos` WRITE;
/*!40000 ALTER TABLE `infos` DISABLE KEYS */;
/*!40000 ALTER TABLE `infos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ip_blocker`
--

DROP TABLE IF EXISTS `ip_blocker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ip_blocker` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(20) NOT NULL,
  `login` varchar(100) DEFAULT NULL,
  `status` varchar(10) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ip` (`ip`),
  KEY `status` (`status`),
  KEY `timestamp` (`timestamp`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ip_blocker`
--

LOCK TABLES `ip_blocker` WRITE;
/*!40000 ALTER TABLE `ip_blocker` DISABLE KEYS */;
INSERT INTO `ip_blocker` VALUES (1,'127.0.0.1','admin','success','2020-04-16 10:00:29'),(2,'192.168.1.29','admin','success','2020-05-13 14:47:22'),(3,'10.152.170.1','admin','success','2022-04-28 09:26:04'),(4,'10.181.99.10','admin','success','2024-02-19 12:44:33'),(5,'10.181.99.10','ecole-du-louvre','failed','2024-02-19 13:41:56'),(6,'10.181.99.10','admin','success','2024-02-19 14:27:44'),(7,'10.181.99.10','admin','success','2024-02-19 15:11:19'),(8,'10.181.99.10','admin','success','2024-02-22 09:01:01'),(9,'10.181.99.10','admin','success','2024-02-22 09:12:09'),(10,'10.152.170.1','admin','success','2024-04-19 14:54:10');
/*!40000 ALTER TABLE `ip_blocker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jours_feries`
--

DROP TABLE IF EXISTS `jours_feries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jours_feries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `annee` varchar(10) DEFAULT NULL,
  `jour` date DEFAULT NULL,
  `ferie` int(1) DEFAULT NULL,
  `fermeture` int(1) DEFAULT NULL,
  `nom` text DEFAULT NULL,
  `commentaire` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jours_feries`
--

LOCK TABLES `jours_feries` WRITE;
/*!40000 ALTER TABLE `jours_feries` DISABLE KEYS */;
/*!40000 ALTER TABLE `jours_feries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lignes`
--

DROP TABLE IF EXISTS `lignes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lignes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lignes`
--

LOCK TABLES `lignes` WRITE;
/*!40000 ALTER TABLE `lignes` DISABLE KEYS */;
/*!40000 ALTER TABLE `lignes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log`
--

DROP TABLE IF EXISTS `log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `msg` text DEFAULT NULL,
  `program` varchar(30) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log`
--

LOCK TABLES `log` WRITE;
/*!40000 ALTER TABLE `log` DISABLE KEYS */;
/*!40000 ALTER TABLE `log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `niveau1` int(11) NOT NULL,
  `niveau2` int(11) NOT NULL,
  `titre` varchar(100) NOT NULL,
  `url` varchar(500) NOT NULL,
  `condition` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES (1,10,0,'Absences','/absence',NULL),(2,10,10,'Voir les absences','/absence',NULL),(3,10,20,'Ajouter une absence','/absence/add',NULL),(4,10,30,'Informations','/absences/info','config!=Planook'),(5,15,0,'Congés','/holiday/index','config=Conges-Enable'),(6,15,10,'Liste des cong&eacute;s','/holiday/index','config=Conges-Enable'),(7,15,15,'Liste des r&eacute;cup&eacute;rations','/holiday/index?recup=1','config=Conges-Enable;Conges-Recuperations'),(8,15,20,'Poser des cong&eacute;s','/holiday/new','config=Conges-Enable'),(9,15,24,'Poser des r&eacute;cup&eacute;rations','/comptime/add','config=Conges-Enable;Conges-Recuperations'),(10,15,26,'Heures supplémentaires','/overtime','config=Conges-Enable'),(11,15,30,'Informations','/holiday-info','config=Conges-Enable'),(12,15,40,'Cr&eacute;dits','/holiday/accounts','config=Conges-Enable'),(13,20,0,'Agenda','/calendar',NULL),(14,30,0,'Planning','/index',NULL),(15,30,90,'Agents volants','/detached','config=Planning-agents-volants'),(16,40,0,'Statistiques','/statistics','config!=Planook'),(17,40,10,'Feuille de temps','/statistics/time','config!=Planook'),(18,40,20,'Par agent','/statistics/agent','config!=Planook'),(19,40,30,'Par poste','/statistics/position','config!=Planook'),(20,40,40,'Par poste (Synth&egrave;se)','/statistics/positionsummary','config!=Planook'),(21,40,50,'Postes de renfort','/statistics/supportposition','config!=Planook'),(22,40,24,'Par service','/statistics/service','config!=Planook'),(23,40,60,'Samedis','/statistics/saturday','config!=Planook'),(24,40,70,'Absences','/statistics/absence','config!=Planook'),(25,40,80,'Présents / absents','/statistics/attendeesmissing','config!=Planook'),(26,40,26,'Par statut','/statistics/status','config!=Planook'),(27,50,0,'Administration','/admin',NULL),(28,50,10,'Informations','/admin/info','config!=Planook'),(29,50,20,'Les activités','/skill','config!=Planook'),(30,50,30,'Les agents','/agent',NULL),(31,50,40,'Les postes','/position',NULL),(32,50,50,'Les mod&egrave;les','/model',NULL),(33,50,60,'Les tableaux','/framework',NULL),(34,50,70,'Jours de fermeture','/closingday','config!=Planook&config=Conges-Enable'),(35,50,75,'Heures de présence','/workinghour','config=PlanningHebdo'),(36,50,77,'Notifications / Validations','/notification','config=Absences-notifications-agent-par-agent'),(37,50,80,'Configuration','/config',NULL),(38,60,0,'Aide','/help',NULL),(39,10,25,'Bloquer les absences','/absence/block','config=Absences-blocage');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personnel`
--

DROP TABLE IF EXISTS `personnel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personnel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` text NOT NULL,
  `prenom` text NOT NULL,
  `mail` text NOT NULL,
  `statut` text NOT NULL,
  `categorie` varchar(30) NOT NULL DEFAULT '',
  `service` text NOT NULL,
  `arrivee` date NOT NULL DEFAULT '0000-00-00',
  `depart` date NOT NULL DEFAULT '0000-00-00',
  `postes` text NOT NULL,
  `actif` varchar(20) NOT NULL DEFAULT 'true',
  `droits` text NOT NULL,
  `login` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `commentaires` text NOT NULL,
  `last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `heures_hebdo` varchar(6) NOT NULL,
  `heures_travail` float NOT NULL,
  `sites` text NOT NULL,
  `temps` text NOT NULL,
  `informations` text NOT NULL,
  `recup` text NOT NULL,
  `supprime` enum('0','1','2') NOT NULL DEFAULT '0',
  `mails_responsables` text NOT NULL,
  `matricule` varchar(100) NOT NULL DEFAULT '',
  `code_ics` varchar(100) DEFAULT NULL,
  `url_ics` text DEFAULT NULL,
  `check_ics` varchar(10) DEFAULT '[1,1,1]',
  `check_hamac` int(1) NOT NULL DEFAULT 1,
  `conges_credit` float DEFAULT NULL,
  `conges_reliquat` float DEFAULT NULL,
  `conges_anticipation` float DEFAULT NULL,
  `comp_time` float DEFAULT NULL,
  `conges_annuel` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personnel`
--

LOCK TABLES `personnel` WRITE;
/*!40000 ALTER TABLE `personnel` DISABLE KEYS */;
INSERT INTO `personnel` VALUES (1,'admin','admin','admin@example.com','','','','0000-00-00','0000-00-00','[]','Inactif','[\"6\",\"9\",\"201\",\"701\",\"3\",\"4\",\"21\",\"1101\",\"1201\",\"301\",\"1001\",\"901\",\"801\",\"22\",\"5\",\"17\",\"1301\",\"23\",6,99,100,20]','admin','$2y$10$U9pEMaKRrZWlY1.Eo2Lme.FsuPwI9k/WRUqb9iw.WRiYUkvNzZB5q','Compte cr&eacute;&eacute; lors de l&apos;installation du planning','2024-04-19 16:54:10','0',0,'','[[\"\",\"\",\"\",\"\"],[\"\",\"\",\"\",\"\"],[\"\",\"\",\"\",\"\"],[\"\",\"\",\"\",\"\"],[\"\",\"\",\"\",\"\"],[\"\",\"\",\"\",\"\"]]','','','0','','',NULL,NULL,'[0,0,0]',0,NULL,NULL,0,0,NULL),(2,'Tout le monde','','','','','','0000-00-00','0000-00-00','','Actif','[99,100]','','','Compte cr&eacute;&eacute; lors de l&apos;installation du planning','0000-00-00 00:00:00','',0,'','[[\"09:00:00\",\"12:00:00\",\"13:00:00\",\"17:00:00\"],[\"09:00:00\",\"12:00:00\",\"13:00:00\",\"17:00:00\"],[\"09:00:00\",\"12:00:00\",\"13:00:00\",\"17:00:00\"],[\"09:00:00\",\"12:00:00\",\"13:00:00\",\"17:00:00\"],[\"09:00:00\",\"12:00:00\",\"13:00:00\",\"17:00:00\"],[\"\",\"\",\"\",\"\"]]','','','0','','',NULL,NULL,'[1,1,1]',1,NULL,NULL,0,0,NULL),(3,'Adèle','Adèle','adele@example.com','','','','0000-00-00','0000-00-00','[\"13\",\"14\",\"15\",\"16\",\"17\"]','Actif','[99,100]','adele.adele','$2y$10$1FaR3jpUtDAHQHiHHGTfjOqHcTDn77ExDpzzrj7P5O25dMvCUAcXq','','0000-00-00 00:00:00','20',20,'','','','','0','','',NULL,NULL,'[0,0,0]',0,NULL,NULL,NULL,NULL,NULL),(4,'Garance','Garance','garance@example.com','','','','0000-00-00','0000-00-00','[\"16\",\"17\",\"13\",\"14\",\"15\"]','Actif','[99,100]','garance.garance','$2y$10$wwHMcKBvGdNkQtbc8QEoHuAmVysuocs83qTS4NIktZbcgwB/P5PAC','','0000-00-00 00:00:00','20',20,'','','','','0','','',NULL,'','[0,0,0]',0,NULL,NULL,NULL,NULL,NULL),(5,'Julie','Julie','julie@example.com','','','','0000-00-00','0000-00-00','[]','Actif','[99,100]','julie.julie','$2y$10$2O0hiOyON1E2Pe1mLZy96.9C3J979hP8hxiLhU0eycAKih.K2AsTy','','0000-00-00 00:00:00','10',0,'','','','','0','','',NULL,'','[0,0,0]',0,NULL,NULL,NULL,NULL,NULL),(6,'Pauline','Pauline','pauline@example.com','','','','0000-00-00','0000-00-00','[\"16\",\"17\",\"13\",\"14\",\"15\"]','Actif','[99,100]','pauline.pauline','$2y$10$aDDTjT6hkUnMznhLXNEI1O54LEQGt22aTsKMl0afFL1BXR/B.eIda','','0000-00-00 00:00:00','12',37.5,'','','','','0','','',NULL,'','[0,0,0]',0,NULL,NULL,NULL,NULL,NULL),(7,'Gabriel','Gabriel','gabriel@example.com','','','','0000-00-00','0000-00-00','[]','Actif','[99,100]','gabriel.gabriel','$2y$10$jlsF7twXBuIDc0NvuHsR7O9qdQlVHZticc16hH3TssCK2RkmWQkSK','','0000-00-00 00:00:00','20',0,'','','','','0','','',NULL,'','[0,0,0]',0,NULL,NULL,NULL,NULL,NULL),(8,'Benjamin','Benjamin','benjamin@example.com','','','','0000-00-00','0000-00-00','[\"16\",\"17\",\"13\",\"14\",\"15\"]','Actif','[99,100]','benjamin.benjamin','$2y$10$A7BEPL9HbkU4DLw.nyC4f.7o1X3yMVfNhXeYf.BSwx10XXZdd5/uS','','0000-00-00 00:00:00','20',37.5,'','','','','0','','',NULL,'','[0,0,0]',0,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `personnel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl_notes`
--

DROP TABLE IF EXISTS `pl_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `site` int(3) NOT NULL DEFAULT 1,
  `text` text DEFAULT NULL,
  `perso_id` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl_notes`
--

LOCK TABLES `pl_notes` WRITE;
/*!40000 ALTER TABLE `pl_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `pl_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl_notifications`
--

DROP TABLE IF EXISTS `pl_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `site` int(2) NOT NULL DEFAULT 1,
  `update_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `data` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `site` (`site`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl_notifications`
--

LOCK TABLES `pl_notifications` WRITE;
/*!40000 ALTER TABLE `pl_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `pl_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl_position_history`
--

DROP TABLE IF EXISTS `pl_position_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl_position_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `perso_ids` text NOT NULL,
  `date` date DEFAULT NULL,
  `beginning` time NOT NULL,
  `end` time NOT NULL,
  `site` int(11) NOT NULL DEFAULT 1,
  `position` int(11) NOT NULL,
  `action` varchar(20) NOT NULL,
  `undone` tinyint(4) NOT NULL DEFAULT 0,
  `archive` tinyint(4) NOT NULL DEFAULT 0,
  `play_before` tinyint(4) NOT NULL DEFAULT 0,
  `updated_by` int(11) NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl_position_history`
--

LOCK TABLES `pl_position_history` WRITE;
/*!40000 ALTER TABLE `pl_position_history` DISABLE KEYS */;
INSERT INTO `pl_position_history` VALUES (1,'[]','2024-02-19','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:18:01'),(2,'[]','2024-02-20','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:18:01'),(3,'[]','2024-02-21','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:18:01'),(4,'[]','2024-02-22','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:18:01'),(5,'[]','2024-02-23','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:18:01'),(6,'[]','2024-02-24','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:18:01'),(7,'[]','2024-02-25','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:18:01'),(8,'[]','2024-02-19','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:39:37'),(9,'[]','2024-02-20','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:39:37'),(10,'[]','2024-02-21','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:39:37'),(11,'[]','2024-02-22','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:39:37'),(12,'[]','2024-02-23','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:39:37'),(13,'[]','2024-02-24','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:39:37'),(14,'[]','2024-02-25','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:39:37'),(15,'[]','2024-02-19','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:40:09'),(16,'[]','2024-02-20','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:40:09'),(17,'[]','2024-02-21','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:40:09'),(18,'[]','2024-02-22','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:40:09'),(19,'[]','2024-02-23','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:40:09'),(20,'[]','2024-02-24','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:40:09'),(21,'[]','2024-02-25','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:40:09'),(22,'[\"4\"]','2024-02-20','14:00:00','15:00:00',1,1,'put',0,1,0,1,'2024-02-22 10:45:54'),(23,'[\"6\"]','2024-02-20','14:00:00','15:00:00',1,2,'put',0,1,0,1,'2024-02-22 10:45:56'),(24,'[\"8\"]','2024-02-20','14:00:00','15:00:00',1,3,'put',0,1,0,1,'2024-02-22 10:45:57'),(25,'[\"3\"]','2024-02-20','16:00:00','17:00:00',1,1,'put',0,1,0,1,'2024-02-22 10:46:01'),(26,'[\"4\"]','2024-02-20','16:00:00','17:00:00',1,2,'put',0,1,0,1,'2024-02-22 10:46:03'),(27,'[]','2024-02-19','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:46:09'),(28,'[]','2024-02-20','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:46:09'),(29,'[]','2024-02-21','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:46:09'),(30,'[]','2024-02-22','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:46:09'),(31,'[]','2024-02-23','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:46:09'),(32,'[]','2024-02-24','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:46:09'),(33,'[]','2024-02-25','00:00:00','23:59:59',1,0,'delete-planning',0,1,0,1,'2024-02-22 10:46:09');
/*!40000 ALTER TABLE `pl_position_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl_poste`
--

DROP TABLE IF EXISTS `pl_poste`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl_poste` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `perso_id` int(11) NOT NULL DEFAULT 0,
  `date` date NOT NULL DEFAULT '0000-00-00',
  `poste` int(11) NOT NULL DEFAULT 0,
  `absent` enum('0','1','2') NOT NULL DEFAULT '0',
  `chgt_login` int(4) DEFAULT NULL,
  `chgt_time` datetime NOT NULL,
  `debut` time NOT NULL,
  `fin` time NOT NULL,
  `supprime` enum('0','1') DEFAULT '0',
  `site` int(3) DEFAULT 1,
  `grise` enum('0','1') DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `site` (`site`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl_poste`
--

LOCK TABLES `pl_poste` WRITE;
/*!40000 ALTER TABLE `pl_poste` DISABLE KEYS */;
/*!40000 ALTER TABLE `pl_poste` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl_poste_cellules`
--

DROP TABLE IF EXISTS `pl_poste_cellules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl_poste_cellules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero` int(11) NOT NULL,
  `tableau` int(11) NOT NULL,
  `ligne` int(11) NOT NULL,
  `colonne` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl_poste_cellules`
--

LOCK TABLES `pl_poste_cellules` WRITE;
/*!40000 ALTER TABLE `pl_poste_cellules` DISABLE KEYS */;
INSERT INTO `pl_poste_cellules` VALUES (1,3,0,0,9),(2,3,0,1,4),(3,3,0,2,4),(4,3,2,0,4);
/*!40000 ALTER TABLE `pl_poste_cellules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl_poste_history`
--

DROP TABLE IF EXISTS `pl_poste_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl_poste_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `perso_ids` mediumtext DEFAULT NULL,
  `date` date NOT NULL DEFAULT '0000-00-00',
  `beginning` time NOT NULL DEFAULT '00:00:00',
  `end` time NOT NULL DEFAULT '00:00:00',
  `site` int(11) NOT NULL DEFAULT 1,
  `position` int(11) NOT NULL DEFAULT 0,
  `action` varchar(10) DEFAULT NULL,
  `updated_by` int(11) NOT NULL DEFAULT 0,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl_poste_history`
--

LOCK TABLES `pl_poste_history` WRITE;
/*!40000 ALTER TABLE `pl_poste_history` DISABLE KEYS */;
INSERT INTO `pl_poste_history` VALUES (1,'[]','2022-05-24','12:00:00','13:00:00',1,51,'cross',1,'2022-05-25 07:10:55'),(2,'[394,204]','2022-05-24','12:00:00','13:00:00',1,51,'cross',1,'2022-05-25 07:12:58'),(3,NULL,'2022-05-24','12:00:00','13:00:00',1,51,'cross',1,'2022-05-25 07:55:03'),(4,'[471,204]','2022-05-24','12:00:00','13:00:00',1,51,'cross',1,'2022-05-25 07:56:18'),(5,'[495]','2022-05-24','12:00:00','13:00:00',1,52,'cross',1,'2022-05-25 07:58:16'),(6,'[471,495]','2022-05-24','13:00:00','14:00:00',1,51,'delete',1,'2022-05-25 08:01:00'),(7,'[264]','2022-05-24','13:00:00','14:00:00',1,52,'delete',1,'2022-05-25 08:01:38'),(8,'[446,495]','2022-05-24','14:00:00','15:00:00',1,51,'delete',1,'2022-05-25 08:01:41'),(9,'[471,204]','2022-05-24','12:00:00','13:00:00',1,51,'delete',1,'2022-05-25 08:08:13'),(10,'[204,394]','2022-05-24','11:00:00','12:00:00',1,51,'delete',1,'2022-05-25 08:08:27'),(11,'[262,58]','2022-05-24','14:00:00','15:00:00',1,52,'delete',1,'2022-05-25 08:09:49'),(12,'[204,199]','2022-05-24','15:00:00','16:00:00',1,52,'delete',1,'2022-05-25 08:10:26'),(13,'[16]','2022-05-24','11:00:00','12:00:00',1,52,'delete',1,'2022-05-25 08:10:54'),(14,'[266]','2022-05-24','09:30:00','11:00:00',1,52,'delete',1,'2022-05-25 08:11:11'),(15,'[\"204\"]','2022-05-24','09:30:00','11:00:00',1,51,'delete',1,'2022-05-25 08:12:34'),(16,'[106]','2022-05-24','09:30:00','11:00:00',1,51,'delete',1,'2022-05-25 08:13:59'),(17,'[204,495]','2022-05-24','13:00:00','14:00:00',1,51,'delete',1,'2022-05-25 08:14:17'),(18,'[471]','2022-05-24','13:00:00','14:00:00',1,51,'delete',1,'2022-05-25 08:14:29'),(19,'[495]','2022-05-24','13:00:00','14:00:00',1,51,'cross',1,'2022-05-25 08:14:38'),(20,'[204]','2022-05-24','13:00:00','14:00:00',1,51,'cross',1,'2022-05-25 08:14:43'),(21,'[495,204]','2022-05-24','13:00:00','14:00:00',1,51,'delete',1,'2022-05-25 08:14:47'),(22,'[495,204]','2022-05-24','13:00:00','14:00:00',1,51,'cross',1,'2022-05-25 08:14:57');
/*!40000 ALTER TABLE `pl_poste_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl_poste_horaires`
--

DROP TABLE IF EXISTS `pl_poste_horaires`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl_poste_horaires` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `debut` time NOT NULL DEFAULT '00:00:00',
  `fin` time NOT NULL DEFAULT '00:00:00',
  `tableau` int(11) NOT NULL,
  `numero` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl_poste_horaires`
--

LOCK TABLES `pl_poste_horaires` WRITE;
/*!40000 ALTER TABLE `pl_poste_horaires` DISABLE KEYS */;
INSERT INTO `pl_poste_horaires` VALUES (9,'16:00:00','17:00:00',0,2),(8,'15:00:00','16:00:00',0,2),(7,'14:00:00','15:00:00',0,2),(24,'11:00:00','12:00:00',0,3),(23,'10:00:00','11:00:00',0,3),(22,'09:00:00','10:00:00',0,3),(10,'17:00:00','18:00:00',0,2),(11,'18:00:00','19:00:00',0,2),(12,'14:00:00','15:00:00',1,2),(13,'15:00:00','16:00:00',1,2),(14,'16:00:00','17:00:00',1,2),(15,'17:00:00','18:00:00',1,2),(16,'18:00:00','19:00:00',1,2),(17,'14:00:00','15:00:00',2,2),(18,'15:00:00','16:00:00',2,2),(19,'16:00:00','17:00:00',2,2),(20,'17:00:00','18:00:00',2,2),(21,'18:00:00','19:00:00',2,2),(25,'12:00:00','13:00:00',0,3),(26,'13:00:00','14:00:00',0,3),(27,'14:00:00','15:00:00',0,3),(28,'15:00:00','16:00:00',0,3),(29,'16:00:00','17:00:00',0,3),(30,'17:00:00','18:00:00',0,3),(31,'09:30:00','11:00:00',1,3),(32,'11:00:00','12:30:00',1,3),(33,'12:30:00','14:00:00',1,3),(34,'14:00:00','15:30:00',1,3),(35,'15:30:00','17:00:00',1,3),(36,'09:00:00','10:00:00',2,3),(37,'10:00:00','11:00:00',2,3),(38,'11:00:00','12:00:00',2,3),(39,'12:00:00','13:00:00',2,3),(40,'13:00:00','14:00:00',2,3),(41,'09:00:00','10:00:00',0,4);
/*!40000 ALTER TABLE `pl_poste_horaires` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl_poste_lignes`
--

DROP TABLE IF EXISTS `pl_poste_lignes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl_poste_lignes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero` int(11) NOT NULL,
  `tableau` int(11) NOT NULL,
  `ligne` int(11) NOT NULL,
  `poste` varchar(30) NOT NULL,
  `type` enum('poste','ligne','titre','classe') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl_poste_lignes`
--

LOCK TABLES `pl_poste_lignes` WRITE;
/*!40000 ALTER TABLE `pl_poste_lignes` DISABLE KEYS */;
INSERT INTO `pl_poste_lignes` VALUES (1,2,0,0,'Service public','titre'),(2,2,0,0,'jaune','classe'),(3,2,1,0,'Tâches internes','titre'),(4,2,1,0,'bleu','classe'),(5,2,2,0,'Animations','titre'),(6,2,2,0,'rouge','classe'),(7,2,0,0,'1','poste'),(8,2,0,1,'2','poste'),(9,2,0,2,'3','poste'),(10,2,1,0,'4','poste'),(11,2,2,0,'6','poste'),(12,3,0,0,'Service public','titre'),(13,3,0,0,'violet','classe'),(14,3,1,0,'Inscriptions','titre'),(15,3,1,0,'bleu','classe'),(16,3,2,0,'Animations','titre'),(17,3,2,0,'vert','classe'),(18,3,0,0,'1','poste'),(19,3,0,1,'5','poste'),(20,3,0,2,'4','poste'),(21,3,1,0,'3','poste'),(22,3,1,1,'2','poste'),(23,3,2,0,'6','poste'),(24,4,0,0,'Fermeture','titre'),(25,4,0,0,'rouge','classe');
/*!40000 ALTER TABLE `pl_poste_lignes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl_poste_modeles`
--

DROP TABLE IF EXISTS `pl_poste_modeles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl_poste_modeles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model_id` int(11) NOT NULL DEFAULT 0,
  `perso_id` int(11) NOT NULL,
  `poste` int(11) NOT NULL,
  `commentaire` text NOT NULL,
  `debut` time NOT NULL,
  `fin` time NOT NULL,
  `tableau` varchar(20) NOT NULL,
  `jour` varchar(10) NOT NULL,
  `site` int(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl_poste_modeles`
--

LOCK TABLES `pl_poste_modeles` WRITE;
/*!40000 ALTER TABLE `pl_poste_modeles` DISABLE KEYS */;
/*!40000 ALTER TABLE `pl_poste_modeles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl_poste_modeles_tab`
--

DROP TABLE IF EXISTS `pl_poste_modeles_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl_poste_modeles_tab` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` text NOT NULL,
  `model_id` int(11) NOT NULL DEFAULT 0,
  `jour` int(11) NOT NULL,
  `tableau` int(11) NOT NULL,
  `site` int(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl_poste_modeles_tab`
--

LOCK TABLES `pl_poste_modeles_tab` WRITE;
/*!40000 ALTER TABLE `pl_poste_modeles_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `pl_poste_modeles_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl_poste_tab`
--

DROP TABLE IF EXISTS `pl_poste_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl_poste_tab` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tableau` int(20) NOT NULL,
  `nom` text NOT NULL,
  `site` int(2) NOT NULL DEFAULT 1,
  `supprime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl_poste_tab`
--

LOCK TABLES `pl_poste_tab` WRITE;
/*!40000 ALTER TABLE `pl_poste_tab` DISABLE KEYS */;
INSERT INTO `pl_poste_tab` VALUES (1,2,'Mardi-Jeudi-Vendredi',1,NULL),(2,3,'Mercredi-Samedi',1,NULL),(3,4,'Fermeture',1,NULL);
/*!40000 ALTER TABLE `pl_poste_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl_poste_tab_affect`
--

DROP TABLE IF EXISTS `pl_poste_tab_affect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl_poste_tab_affect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `tableau` int(11) NOT NULL,
  `site` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl_poste_tab_affect`
--

LOCK TABLES `pl_poste_tab_affect` WRITE;
/*!40000 ALTER TABLE `pl_poste_tab_affect` DISABLE KEYS */;
/*!40000 ALTER TABLE `pl_poste_tab_affect` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl_poste_tab_grp`
--

DROP TABLE IF EXISTS `pl_poste_tab_grp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl_poste_tab_grp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` text DEFAULT NULL,
  `lundi` int(11) DEFAULT NULL,
  `mardi` int(11) DEFAULT NULL,
  `mercredi` int(11) DEFAULT NULL,
  `jeudi` int(11) DEFAULT NULL,
  `vendredi` int(11) DEFAULT NULL,
  `samedi` int(11) DEFAULT NULL,
  `dimanche` int(11) DEFAULT NULL,
  `site` int(2) NOT NULL DEFAULT 1,
  `supprime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl_poste_tab_grp`
--

LOCK TABLES `pl_poste_tab_grp` WRITE;
/*!40000 ALTER TABLE `pl_poste_tab_grp` DISABLE KEYS */;
INSERT INTO `pl_poste_tab_grp` VALUES (1,'Semaine',4,2,3,2,2,3,NULL,1,NULL);
/*!40000 ALTER TABLE `pl_poste_tab_grp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl_poste_verrou`
--

DROP TABLE IF EXISTS `pl_poste_verrou`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl_poste_verrou` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL DEFAULT '0000-00-00',
  `verrou` int(1) NOT NULL DEFAULT 0,
  `validation` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `perso` int(11) NOT NULL DEFAULT 0,
  `verrou2` int(1) NOT NULL DEFAULT 0,
  `validation2` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `perso2` int(11) NOT NULL DEFAULT 0,
  `vivier` int(1) NOT NULL DEFAULT 0,
  `site` int(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl_poste_verrou`
--

LOCK TABLES `pl_poste_verrou` WRITE;
/*!40000 ALTER TABLE `pl_poste_verrou` DISABLE KEYS */;
/*!40000 ALTER TABLE `pl_poste_verrou` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `planning_hebdo`
--

DROP TABLE IF EXISTS `planning_hebdo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `planning_hebdo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `perso_id` int(11) NOT NULL,
  `debut` date NOT NULL,
  `fin` date NOT NULL,
  `temps` text NOT NULL,
  `breaktime` text NOT NULL,
  `saisie` timestamp NOT NULL DEFAULT current_timestamp(),
  `modif` int(11) NOT NULL DEFAULT 0,
  `modification` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `valide_n1` int(11) NOT NULL DEFAULT 0,
  `validation_n1` timestamp NULL DEFAULT NULL,
  `valide` int(11) NOT NULL DEFAULT 0,
  `validation` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `actuel` int(1) NOT NULL DEFAULT 0,
  `remplace` int(11) NOT NULL DEFAULT 0,
  `cle` varchar(100) DEFAULT NULL,
  `exception` int(11) NOT NULL DEFAULT 0,
  `nb_semaine` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cle` (`cle`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `planning_hebdo`
--

LOCK TABLES `planning_hebdo` WRITE;
/*!40000 ALTER TABLE `planning_hebdo` DISABLE KEYS */;
INSERT INTO `planning_hebdo` VALUES (1,3,'2024-01-01','2035-12-31','[[\"09:00:00\",\"\",\"\",\"17:00:00\"],[\"10:00:00\",\"\",\"\",\"19:00:00\"],[\"09:00:00\",\"\",\"\",\"18:00:00\"],[\"06:00:00\",\"\",\"\",\"19:00:00\"],[\"10:00:00\",\"\",\"\",\"19:00:00\"],[\"09:00:00\",\"\",\"\",\"17:00:00\"]]','[1,1,1,1,1,1]','2024-02-22 09:45:09',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',1,'2024-02-22 09:45:09',1,0,NULL,0,1),(2,6,'2024-01-01','2035-12-31','[[\"09:00:00\",\"\",\"\",\"17:00:00\"],[\"10:00:00\",\"\",\"\",\"19:00:00\"],[\"09:00:00\",\"\",\"\",\"18:00:00\"],[\"06:00:00\",\"\",\"\",\"19:00:00\"],[\"10:00:00\",\"\",\"\",\"19:00:00\"],[\"09:00:00\",\"\",\"\",\"17:00:00\"]]','[1,1,1,1,1,1]','2024-02-22 09:45:16',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',1,'2024-02-22 09:45:16',1,0,NULL,0,1),(3,5,'2024-01-01','2035-12-31','[[\"09:00:00\",\"\",\"\",\"17:00:00\"],[\"10:00:00\",\"\",\"\",\"19:00:00\"],[\"09:00:00\",\"\",\"\",\"18:00:00\"],[\"06:00:00\",\"\",\"\",\"19:00:00\"],[\"10:00:00\",\"\",\"\",\"19:00:00\"],[\"09:00:00\",\"\",\"\",\"17:00:00\"]]','[1,1,1,1,1,1]','2024-02-22 09:45:22',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',1,'2024-02-22 09:45:22',1,0,NULL,0,1),(4,4,'2024-01-01','2035-12-31','[[\"09:00:00\",\"\",\"\",\"17:00:00\"],[\"10:00:00\",\"\",\"\",\"19:00:00\"],[\"09:00:00\",\"\",\"\",\"18:00:00\"],[\"06:00:00\",\"\",\"\",\"19:00:00\"],[\"10:00:00\",\"\",\"\",\"19:00:00\"],[\"09:00:00\",\"\",\"\",\"17:00:00\"]]','[1,1,1,1,1,1]','2024-02-22 09:45:30',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',1,'2024-02-22 09:45:30',1,0,NULL,0,1),(5,7,'2024-01-01','2035-12-31','[[\"09:00:00\",\"\",\"\",\"17:00:00\"],[\"10:00:00\",\"\",\"\",\"19:00:00\"],[\"09:00:00\",\"\",\"\",\"18:00:00\"],[\"06:00:00\",\"\",\"\",\"19:00:00\"],[\"10:00:00\",\"\",\"\",\"19:00:00\"],[\"09:00:00\",\"\",\"\",\"17:00:00\"]]','[1,1,1,1,1,1]','2024-02-22 09:45:35',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',1,'2024-02-22 09:45:35',1,0,NULL,0,1),(6,8,'2024-01-01','2035-12-31','[[\"09:00:00\",\"\",\"\",\"17:00:00\"],[\"10:00:00\",\"\",\"\",\"19:00:00\"],[\"09:00:00\",\"\",\"\",\"18:00:00\"],[\"06:00:00\",\"\",\"\",\"19:00:00\"],[\"10:00:00\",\"\",\"\",\"19:00:00\"],[\"09:00:00\",\"\",\"\",\"17:00:00\"]]','[1,1,1,1,1,1]','2024-02-22 09:45:41',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00',1,'2024-02-22 09:45:41',1,0,NULL,0,1);
/*!40000 ALTER TABLE `planning_hebdo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `postes`
--

DROP TABLE IF EXISTS `postes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `postes` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `nom` text NOT NULL,
  `groupe` text NOT NULL,
  `groupe_id` int(11) NOT NULL DEFAULT 0,
  `obligatoire` varchar(15) NOT NULL,
  `etage` text NOT NULL,
  `activites` text NOT NULL,
  `statistiques` enum('0','1') DEFAULT '1',
  `teleworking` enum('0','1') NOT NULL DEFAULT '0',
  `bloquant` enum('0','1') DEFAULT '1',
  `lunch` tinyint(1) NOT NULL DEFAULT 0,
  `site` int(1) DEFAULT 1,
  `categories` text DEFAULT NULL,
  `supprime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `postes`
--

LOCK TABLES `postes` WRITE;
/*!40000 ALTER TABLE `postes` DISABLE KEYS */;
INSERT INTO `postes` VALUES (1,'Accueil 1','1',0,'Obligatoire','2','[\"16\"]','1','0','1',0,0,'[]',NULL),(2,'Accueil 2','1',0,'Obligatoire','5','[\"16\"]','1','0','1',0,0,'[]',NULL),(3,'Inscription','1',0,'Obligatoire','2','[\"13\"]','1','0','1',0,0,'[]',NULL),(4,'Rangement','1',0,'Obligatoire','2','[\"15\"]','1','0','1',0,0,'[]',NULL),(5,'Prêt - retour','1',0,'Obligatoire','2','[\"14\"]','1','0','1',0,0,'[]',NULL),(6,'Animations','3',0,'Obligatoire','2','[\"17\"]','1','0','1',0,0,'[]',NULL);
/*!40000 ALTER TABLE `postes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recuperations`
--

DROP TABLE IF EXISTS `recuperations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recuperations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `perso_id` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `date2` date DEFAULT NULL,
  `heures` float DEFAULT NULL,
  `etat` varchar(20) DEFAULT NULL,
  `commentaires` text DEFAULT NULL,
  `saisie` timestamp NOT NULL DEFAULT current_timestamp(),
  `saisie_par` int(11) NOT NULL,
  `modif` int(11) NOT NULL DEFAULT 0,
  `modification` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `valide_n1` int(11) NOT NULL DEFAULT 0,
  `validation_n1` datetime DEFAULT NULL,
  `valide` int(11) NOT NULL DEFAULT 0,
  `validation` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `refus` text DEFAULT NULL,
  `solde_prec` float DEFAULT NULL,
  `solde_actuel` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recuperations`
--

LOCK TABLES `recuperations` WRITE;
/*!40000 ALTER TABLE `recuperations` DISABLE KEYS */;
/*!40000 ALTER TABLE `recuperations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `responsables`
--

DROP TABLE IF EXISTS `responsables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `responsables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `perso_id` int(11) NOT NULL DEFAULT 0,
  `responsable` int(11) NOT NULL DEFAULT 0,
  `level1` int(1) NOT NULL DEFAULT 1,
  `level2` int(1) NOT NULL DEFAULT 0,
  `notification_level1` int(1) NOT NULL DEFAULT 0,
  `notification_level2` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `responsables`
--

LOCK TABLES `responsables` WRITE;
/*!40000 ALTER TABLE `responsables` DISABLE KEYS */;
/*!40000 ALTER TABLE `responsables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `select_abs`
--

DROP TABLE IF EXISTS `select_abs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `select_abs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `valeur` text NOT NULL,
  `rang` int(11) NOT NULL DEFAULT 0,
  `type` int(1) NOT NULL DEFAULT 0,
  `notification_workflow` char(1) DEFAULT NULL,
  `teleworking` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `select_abs`
--

LOCK TABLES `select_abs` WRITE;
/*!40000 ALTER TABLE `select_abs` DISABLE KEYS */;
INSERT INTO `select_abs` VALUES (21,'Entretien',8,0,'A',0),(20,'Réunion',7,0,'A',0),(19,'Stage',6,0,'A',0),(18,'Concours',5,0,'A',0),(17,'Formation',4,0,'A',0),(16,'Congé paternité',3,0,'A',0),(15,'Congé maternité',2,0,'A',0),(14,'Maladie',1,0,'A',0),(13,'Congés payés',0,0,'A',0),(22,'Non justifiée',9,0,'A',0),(23,'Autre',10,0,'A',0);
/*!40000 ALTER TABLE `select_abs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `select_categories`
--

DROP TABLE IF EXISTS `select_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `select_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `valeur` text NOT NULL,
  `rang` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `select_categories`
--

LOCK TABLES `select_categories` WRITE;
/*!40000 ALTER TABLE `select_categories` DISABLE KEYS */;
INSERT INTO `select_categories` VALUES (1,'Cat&eacute;gorie A',10),(2,'Cat&eacute;gorie B',20),(3,'Cat&eacute;gorie C',30);
/*!40000 ALTER TABLE `select_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `select_etages`
--

DROP TABLE IF EXISTS `select_etages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `select_etages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `valeur` text NOT NULL,
  `rang` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `select_etages`
--

LOCK TABLES `select_etages` WRITE;
/*!40000 ALTER TABLE `select_etages` DISABLE KEYS */;
INSERT INTO `select_etages` VALUES (2,'RDC',0),(5,'1er étage',1),(4,'Magasins',3),(6,'2ème étage',2);
/*!40000 ALTER TABLE `select_etages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `select_groupes`
--

DROP TABLE IF EXISTS `select_groupes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `select_groupes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `valeur` text NOT NULL,
  `rang` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `select_groupes`
--

LOCK TABLES `select_groupes` WRITE;
/*!40000 ALTER TABLE `select_groupes` DISABLE KEYS */;
INSERT INTO `select_groupes` VALUES (1,'Service public',0),(2,'Tâches internes',1),(3,'Animations',2);
/*!40000 ALTER TABLE `select_groupes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `select_services`
--

DROP TABLE IF EXISTS `select_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `select_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `valeur` text NOT NULL,
  `rang` int(11) NOT NULL,
  `couleur` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `select_services`
--

LOCK TABLES `select_services` WRITE;
/*!40000 ALTER TABLE `select_services` DISABLE KEYS */;
INSERT INTO `select_services` VALUES (1,'Pôle public',1,''),(2,'Pôle conservation',2,''),(3,'Pôle collection',3,''),(4,'Pôle informatique',4,''),(5,'Pôle administratif',5,''),(6,'Direction',6,'');
/*!40000 ALTER TABLE `select_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `select_statuts`
--

DROP TABLE IF EXISTS `select_statuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `select_statuts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `valeur` text NOT NULL,
  `rang` int(11) NOT NULL DEFAULT 0,
  `couleur` varchar(7) NOT NULL,
  `categorie` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `select_statuts`
--

LOCK TABLES `select_statuts` WRITE;
/*!40000 ALTER TABLE `select_statuts` DISABLE KEYS */;
INSERT INTO `select_statuts` VALUES (14,'Conservateur',0,'',1),(15,'Bibliothécaire',1,'',1),(16,'BIBAS',2,'',2),(17,'Magasinier',3,'',3),(18,'Etudiant',4,'',3),(19,'Autre',5,'',3);
/*!40000 ALTER TABLE `select_statuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volants`
--

DROP TABLE IF EXISTS `volants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `perso_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volants`
--

LOCK TABLES `volants` WRITE;
/*!40000 ALTER TABLE `volants` DISABLE KEYS */;
/*!40000 ALTER TABLE `volants` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-19 16:54:40
